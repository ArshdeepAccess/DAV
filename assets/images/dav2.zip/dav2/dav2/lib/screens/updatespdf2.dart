import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
class UpdatesPdf2 extends StatefulWidget {
  const UpdatesPdf2({Key? key}) : super(key: key);

  @override
  State<UpdatesPdf2> createState() => _UpdatesPdf2State();
}
class _UpdatesPdf2State extends State<UpdatesPdf2> {
  @override
  Widget build(BuildContext context) {
    return Container(

      child: SfPdfViewer.network(
          "https://iafpensioners.gov.in/ords/dav_portal/r/133/files/static/v958/DNI_officers.pdf"
      ),
    );
  }
}
