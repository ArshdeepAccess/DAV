import 'dart:convert';

import 'package:dav2/Models/CourseMatesModel.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'constant.dart';
class Coursemates extends StatefulWidget {
  const Coursemates({Key? key}) : super(key: key);

  @override
  State<Coursemates> createState() => _CoursematesState();
}

class _CoursematesState extends State<Coursemates> {
  List<CourseMatesModel> data = [];

  @override
  void initState() {
    super.initState();
    getData();
  }

  Future<void> getData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var serviceNumber = prefs.getString('ServiceNumber') ?? "";
    final response = await http.get(Uri.parse("${baseURL}/DAVPORTAL//COURSEMATE/${serviceNumber}"));
    if (response.statusCode == 200) {
      var responseBody = jsonDecode(response.body);
      data = (responseBody["items"] as List).map((data) => CourseMatesModel.fromJson(data)).toList();
      setState(() {});
    } else {
      throw Exception('Failed to load album');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: ListView.separated(
            padding: EdgeInsets.all(MediaQuery.of(context).size.width / 20),
            shrinkWrap: true,
            primary: false,
            itemCount: data.length,
            separatorBuilder: (context, position) => const SizedBox(
              height: 10,
            ),
            itemBuilder: (context, position) {
              return Card(
                color: const Color(0xFFd3eaf2),
                child: Padding(
                  padding: EdgeInsets.all(MediaQuery.of(context).size.width / 40),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              const Text("Service  No.", style: TextStyle(fontSize: 15, color: Colors.black, fontWeight: FontWeight.bold)),
                              Text(data[position].penServiceNo.toString()),
                            ],
                          ),
                          Column(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              const Text("Officer Name",
                                  style: TextStyle(
                                    fontSize: 15,
                                    color: Colors.black,
                                    fontWeight:
                                    FontWeight.bold,
                                  )),
                              Text(data[position].avName),
                            ],
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              const Text("Email Id",
                                  style: TextStyle(
                                    fontSize: 15,
                                    color: Colors.black,
                                    fontWeight:
                                    FontWeight.bold,
                                  )),
                              Text(data[position].penEmailId),
                            ],
                          ),
                          Column(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              const Text("Mobile Number",
                                  style: TextStyle(
                                    fontSize: 15,
                                    color: Colors.black,
                                    fontWeight:
                                    FontWeight.bold,
                                  )),
                              Text(data[position].penMobNo),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            })
    );
  }
}
