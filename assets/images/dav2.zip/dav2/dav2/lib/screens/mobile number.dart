import 'package:auto_size_text/auto_size_text.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'hmscreen1.dart';
import 'otp.dart';

class Mobile extends StatefulWidget {
  const Mobile({Key? key}) : super(key: key);
  static String verify = "";
  @override
  State<Mobile> createState() => _MobileState();
}

class _MobileState extends State<Mobile> {
  TextEditingController countrycode = TextEditingController();
  var phone = "";
  @override
  void initState() {
    countrycode.text = "+91";
    super.initState();
  }

  Widget build(BuildContext context) {
    final maxLines;
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFFd3eaf2),
        elevation: 0,
        leading: IconButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => HomeScreen()),
            );
          },
          icon: Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
        ),
        title: Text(
          "Return to app",
          style: TextStyle(
            color: Colors.black,
          ),
        ),
      ),
      body: Container(
        color: Color(0xFFd3eaf2),
        // color: Color(0xFF999ca5),
        // color: Color(0xFFd3eaf2),
        child: Container(
          alignment: Alignment.center,
          // margin: EdgeInsets.only(left: 25, right: 25),
          // margin: EdgeInsets.only(
          //     top: MediaQuery.of(context).size.width / 20),
          margin: EdgeInsets.fromLTRB(
              MediaQuery.of(context).size.width / 20, 0, 20, 0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Image(
                    height: size.height * 0.40,
                    // width: size.width*,
                    image: AssetImage("assets/images/newlogo.png")),
                SizedBox(
                  // height: 20,
                  height: size.height * 0.02,
                ),
                AutoSizeText(
                  "Sign Up to VAYU-SAMPARC",
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                  minFontSize: 20,
                  maxFontSize: 25,
                  maxLines: 1,
                ),
                SizedBox(
                  height: size.height * 0.02,
                ),
                AutoSizeText(
                  "Add your phone number.We'll send you a verification code so we know you are real.",
                  style: TextStyle(
                    fontSize: 15,
                    color: Colors.black,
                  ),
                  minFontSize: 12,
                  maxFontSize: 15,
                  maxLines: 2,
                  textAlign: TextAlign.center,
                ),
                SizedBox(
                  // height: 20,
                  height: size.height * 0.02,
                ),
                Container(
                  height: size.height * 0.07,
                  // height: 55,
                  decoration: BoxDecoration(
                    border: Border.all(width: 1, color: Colors.black),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: [
                      SizedBox(
                        width: size.width * 0.02,
                        // width: 10,
                      ),
                      SizedBox(
                          // width: 40,
                          width: size.width * 0.10,
                          child: TextField(
                            controller: countrycode,
                            decoration:
                                InputDecoration(border: InputBorder.none),
                          )),
                      AutoSizeText(
                        "|",
                        style: TextStyle(
                          fontSize: 33,
                          color: Colors.black,
                        ),
                        minFontSize: 30,
                        maxFontSize: 33,
                        maxLines: 1,
                      ),
                      SizedBox(
                        // width: 10,
                        width: size.width * 0.02,
                      ),
                      Expanded(
                          child: TextField(
                        keyboardType: TextInputType.phone,
                        onChanged: (value) {
                          phone = value;
                        },
                        decoration: InputDecoration(
                            border: InputBorder.none, hintText: "Phone Number"),
                      )),
                    ],
                  ),
                ),
                SizedBox(
                  height: size.height * 0.02,
                  // height: 20,
                ),
                SizedBox(
                  // height: 45,
                  height: size.height * 0.06,
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      await FirebaseAuth.instance.verifyPhoneNumber(
                        phoneNumber: '${countrycode.text + phone}',
                        verificationCompleted:
                            (PhoneAuthCredential credential) {},
                        verificationFailed: (FirebaseAuthException e) {},
                        codeSent: (String verificationId, int? resendToken) {
                          Mobile.verify = verificationId;
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => Otp()),
                          );
                        },
                        codeAutoRetrievalTimeout: (String verificationId) {},
                      );
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //       builder: (context) => OTP()),
                      // );
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Color(0xFFa8d5e5),
                      // 0xFF394361
                      // 0xFFa8d5e5
                    ),
                    child: Text(
                      "SEND OTP",
                    ),
                  ),
                ),
                SizedBox(
                  // height: 10,
                  height: size.height * 0.02,
                ),
                AutoSizeText(
                  "By providing my phone number,I hereby agree and accept the Terms of Service and Privacy policy in use of the app.",
                  style: TextStyle(
                    fontSize: 15,
                    color: Colors.black,
                  ),
                  minFontSize: 12,
                  maxFontSize: 15,
                  maxLines: 3,
                  textAlign: TextAlign.center,
                ),
                SizedBox(
                  height: size.height * 0.02,
                  // height: 20,
                ),
                SizedBox(
                  // height: 45,
                  height: size.height * 0.06,
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => HomeScreen()),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      // primary: Color(0xFF38393d),
                      primary: Color(0xFFa8d5e5),
                      // (0xFFa8d5e5
                    ),
                    child: Text(
                      "Skip for now",
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
