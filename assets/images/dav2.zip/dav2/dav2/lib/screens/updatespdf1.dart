import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
class UpdatesPdf1 extends StatefulWidget {
  const UpdatesPdf1({Key? key}) : super(key: key);

  @override
  State<UpdatesPdf1> createState() => _UpdatesPdf1State();
}

class _UpdatesPdf1State extends State<UpdatesPdf1> {
  @override
  Widget build(BuildContext context) {
    return Container(

      child: SfPdfViewer.network(
          "https://iafpensioners.gov.in/ords/dav_portal/r/133/files/static/v958/assets/pdf/query.pdf"
      ),
    );
  }
}
