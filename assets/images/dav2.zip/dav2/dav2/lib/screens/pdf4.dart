import 'package:dav2/Models/echs_models/dataechs.dart';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

class pdf4 extends StatefulWidget {
  var url = "";
  pdf4(this.url);

  @override
  State<pdf4> createState() => PdfState();
}

class PdfState extends State<pdf4> {
  String? localPath;
  Future<Echs>? futureAlbum;

  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xFF394361),
          title: Text(
            "SERVING THOSE WHO SERVED US",
            style: TextStyle(fontSize: 15),
          ),
        ),
        body: SfPdfViewer.network(widget.url));
  }
}
