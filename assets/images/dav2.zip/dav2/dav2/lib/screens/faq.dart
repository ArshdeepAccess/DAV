// import 'package:flutter/material.dart';
// import 'package:webview_flutter/webview_flutter.dart';
//
// import 'maindrawer.dart';
// class Faq extends StatefulWidget {
//   const Faq({Key? key}) : super(key: key);
//
//   @override
//   State<Faq> createState() => _FaqState();
// }
//
// class _FaqState extends State<Faq> {
//   late WebViewController controller;
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Color(0xFF394361),
//         title: Text(
//           "VAYU-SAMPARC",
//           style: TextStyle(fontSize: 20),
//         ),
//         actions: [
//           IconButton(onPressed: (){},
//               // toggleRecording,
//               icon: Icon(Icons.mic)),
//           Image(image: AssetImage("assets/images/newlogo.png"))],
//       ),
//       drawer: Maindrawer(),
//       body: WebView(
//         javascriptMode: JavascriptMode.unrestricted,
//         initialUrl: "https://iafpensioners.gov.in/ords/dav_portal/r/dte_av/faq-home?P0_ISMOBILE=1 ",
//         onWebViewCreated: (controller){
//           this.controller = controller;
//         },
//       ),
//
//     );
//   }
// }
