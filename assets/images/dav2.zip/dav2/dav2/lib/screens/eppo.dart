import 'dart:convert';
import 'package:dav2/Models/EppoModel.dart';
import 'package:dav2/screens/eppopdf.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'constant.dart';
class Eppo extends StatefulWidget {
  const Eppo({Key? key}) : super(key: key);

  @override
  State<Eppo> createState() => _EppoState();
}

class _EppoState extends State<Eppo> {
  List<EppoModel> data = [];

  @override
  void initState() {
    super.initState();
    getData();
  }

  Future<void> getData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var serviceNumber = prefs.getString('ServiceNumber') ?? "";
    final response = await http.get(Uri.parse("${baseURL}/EPPODOWNLOAD/EPPODOWNLOAD/${serviceNumber}"));
    if (response.statusCode == 200) {
      var responseBody = jsonDecode(response.body);
      data = (responseBody["items"] as List).map((data) => EppoModel.fromJson(data)).toList();
      setState(() {});
    } else {
      throw Exception('Failed to load album');
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xFF394361),
          title: Text(
            "SERVING THOSE WHO SERVED US",
            style: TextStyle(fontSize: 15),
          ),
        ),
        body: ListView.separated(
            padding: EdgeInsets.all(MediaQuery.of(context).size.width / 20),
            shrinkWrap: true,
            primary: false,
            itemCount: data.length,
            separatorBuilder: (context, position) => const SizedBox(
              height: 10,
            ),
            itemBuilder: (context, position) {
              return Column(
                // crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    // height: 40,
                    height: size.height * 0.08,
                    width: size.width * 2,
                    // width: 400,
                    // color: Colors.white,
                    child: Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: MediaQuery.of(context).size.width / 20,
                        vertical: MediaQuery.of(context).size.width / 20,
                      ),
                      // padding:  EdgeInsets.symmetric(horizontal: 16.0,vertical: 8.0),
                      child: Text(
                        "EPPO",
                        style: TextStyle(
                          color: Color(0xFF394361),
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                      left: 5,
                      right: 5,
                    ),
                    // padding: EdgeInsets.fromLTRB(
                    //     MediaQuery.of(context).size.width / 0.001, 0, 0.001, 0),
                    child: Container(
                        color: Colors.white,
                        // color: Color(0xFFe7f2f9),
                        child: ListView.separated(
                            primary: false,
                            itemCount: data.length,
                            separatorBuilder: (context, position) => SizedBox(
                              height: 0,
                            ),
                            shrinkWrap: true,
                            itemBuilder: (context, position) {
                              return Container(
                                child: Table(
                                  columnWidths: const {
                                    0: FlexColumnWidth(),
                                    1: FixedColumnWidth(50),

                                  },
                                  border: TableBorder.all(
                                    color: Colors.grey,
                                  ),
                                  children: [
                                    TableRow(
                                      //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.all(
                                              MediaQuery.of(context)
                                                  .size
                                                  .width /
                                                  40),
                                          // padding: const EdgeInsets.all(8.0),
                                         child: Text(data[position].name),
                                        ),

                                        Padding(
                                          padding: EdgeInsets.all(
                                              MediaQuery.of(context)
                                                  .size
                                                  .width /
                                                  70),
                                          // padding: const EdgeInsets.all(8.0),
                                          child: GestureDetector(
                                            onTap: () {
                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (context) => Eppopdf(data[position].download),

                                                  ));
                                            },
                                            child: Icon(
                                              Icons.picture_as_pdf,color: Colors.red,),

                                          ),
                                        ),

                                      ],
                                    ),
                                  ],
                                ),
                              );
                            })),
                  )
                ],
              );
            })
    );
  }
}

