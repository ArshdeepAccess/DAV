import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
class Iafba extends StatefulWidget {
  const Iafba({Key? key}) : super(key: key);

  @override
  State<Iafba> createState() => _IafbaState();
}

class _IafbaState extends State<Iafba> {
  late WebViewController controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Color(0xFF394361),
          title: Text(
            "VAYU-SAMPARC",
            style: TextStyle(fontSize: 20),
          ),
          actions: [
            IconButton(onPressed: (){},
                // toggleRecording,
                icon: Icon(Icons.mic)),
            Image(image: AssetImage("assets/images/newlogo.png"))],
        ),

      body: WebView(
        javascriptMode: JavascriptMode.unrestricted,
        initialUrl: "https://www.iafpensioners.gov.in/ords/dav_portal/r/iafba1/home",
        onWebViewCreated: (controller){
          this.controller = controller;
        },
      ),

    );
  }
}


