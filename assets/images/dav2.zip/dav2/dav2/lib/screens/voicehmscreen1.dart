// import 'dart:ui';
// import 'package:auto_size_text/auto_size_text.dart';
// import 'package:carousel_slider/carousel_options.dart';
// import 'package:carousel_slider/carousel_slider.dart';
// import 'package:dav2/Iafba.dart';
// import 'package:dav2/Ig1.dart';
// import 'package:dav2/Ig2.dart';
// import 'package:dav2/Ig3.dart';
// import 'package:dav2/Ig4.dart';
// import 'package:dav2/Update.dart';
// import 'package:dav2/api/speech_api.dart';
// import 'package:dav2/disabilitypension.dart';
// import 'package:dav2/familypension.dart';
// import 'package:dav2/placement.dart';
// import 'package:dav2/resettlement.dart';
// import 'package:dav2/servicepension.dart';
// import 'package:flutter/material.dart';
// import 'Ig5.dart';
// import 'Ig6.dart';
// import 'Ig7.dart';
// import 'Ig8.dart';
// import 'Ig9.dart';
// import 'Nok-login.dart';
// import 'Vet-login.dart';
// import 'faq.dart';
// import 'maindrawer.dart';
// import 'welfare.dart';
//
// class HomeScreen extends StatefulWidget {
//   const HomeScreen({Key? key}) : super(key: key);
//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }
//
// class _HomeScreenState extends State<HomeScreen> {
//   String text = 'Press the button and start speaking';
//   @override
//
//   Widget build(BuildContext context) {
//     Size size = MediaQuery.of(context).size;
//     final maxLines;
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Color(0xFF394361),
//         // Color(0xFFffc166),
//         // Color(0xFF2c444d),
//         // Color(0xFF474b50),
//         title: Text(
//           "VAYU-SAMPARC",
//           style: TextStyle(fontSize: 20),
//         ),
//         actions:  [
//           IconButton(onPressed: toggleRecording,
//               icon: Icon(Icons.mic_none,size: 36,)),
//           Image(image: AssetImage("assets/images/newlogo.png"))],
//       ),
//       drawer: Maindrawer(),
//       body: SingleChildScrollView(
//         child: Column(
//           children: [
//             Stack(
//               children: [
//                 Container(
//                   child: BackdropFilter(
//                     filter: ImageFilter.blur(sigmaX: 0.5, sigmaY: 0.5),
//                     child: Container(
//                       color: Colors.grey.withOpacity(0.1),
//                     ),
//                   ),
//                   // width: MediaQuery.of(context).size.width*1.5,
//                   // height: MediaQuery.of(context).size.height*0.43,
//                   // height: 350,
//                   // width: 400,
//                   height: size.height * 0.16,
//                   width: size.width * 1.5,
//                   decoration: BoxDecoration(
//                     image: DecorationImage(
//                       image: AssetImage(
//                         "assets/images/B2.jpg",
//                       ),
//                       fit: BoxFit.fill,
//                     ),
//                   ),
//                 ),
//                 Container(
//                   // child: Image(
//                   //     image: AssetImage(
//                   //       "assets/images/newlogo.png",
//                   //     )),
//                   height: size.height * 0.17,
//                   width: size.width * 1.5,
//                   // height: 350,
//                   // width: 400,
//                   // width: MediaQuery.of(context).size.width*1.5 ,
//                   // height: MediaQuery.of(context).size.height*0.43,
//                   // padding: EdgeInsets.fromLTRB(20,60,30,20),
//                   padding: EdgeInsets.symmetric(
//                     horizontal: MediaQuery.of(context).size.width / 30,
//                     vertical: MediaQuery.of(context).size.width / 10,
//                   ),
//                 ),
//               ],
//             ),
//             Container(
//               // height: 130,
//               // width: 320,
//               height: size.height * 0.14,
//               width: size.width * 0.89,
//               child: Card(
//                 color: Color(0xFFf2fcff),
//                 // margin: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width/40,
//                 // vertical: MediaQuery.of(context).size.width/80,
//                 // ),
//                 margin: EdgeInsets.fromLTRB(
//                     MediaQuery.of(context).size.width / 60, 0.08, 3, 8),
//                 child: Column(
//                   children: [
//                     Row(
//                       children: [
//                         Padding(
//                           padding: EdgeInsets.only(
//                               left: MediaQuery.of(context).size.width / 30),
//                           child: Text(
//                             "Login",
//                             style: TextStyle(
//                               fontWeight: FontWeight.bold,
//                               color: Color(0xFF474b50),
//                               fontSize: 20,
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       children: [
//                         Container(
//                           height: size.height * 0.08,
//                           width: size.width * 0.20,
//                           // height: 70,
//                           // width:90,
//                           // margin: EdgeInsets.only(top:15),
//                           // padding: EdgeInsets.only(top: 10),
//                           padding: EdgeInsets.only(
//                               top: MediaQuery.of(context).size.width / 30),
//                           margin: EdgeInsets.only(
//                               top: MediaQuery.of(context).size.width / 30),
//                           decoration: BoxDecoration(
//                             color: Color(0xFFa8d5e5),
//                             border: Border.all(width: 0.3, color: Colors.grey),
//                             borderRadius: BorderRadius.circular(8),
//                           ),
//
//                           child: GestureDetector(
//                             onTap: () {
//                               Navigator.push(
//                                 context,
//                                 MaterialPageRoute(builder: (context) => New()),
//                               );
//                             },
//                             child: Column(
//                               children: [
//                                 Container(
//
//                                   // height: 30
//                                   // ,width: 50,
//                                     height: size.height * 0.04,
//                                     width: size.width * 0.20,
//                                     child: Image(
//                                         image: AssetImage(
//                                             "assets/images/veteran-icon.png"))),
//                                 Padding(
//                                   padding: EdgeInsets.symmetric(
//                                     horizontal:
//                                     MediaQuery.of(context).size.width / 30,
//                                     vertical:
//                                     MediaQuery.of(context).size.width / 170,
//                                   ),
//                                   child: AutoSizeText(
//                                     "VETERANS",
//                                     style: TextStyle(
//                                         color: Color(0xFF2c444d),
//                                         fontSize: 9,
//                                         fontWeight: FontWeight.bold),
//                                     minFontSize: 7,
//                                     maxFontSize: 9,
//                                     maxLines: 1,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                           // ),
//                         ),
//                         Container(
//                           height: size.height * 0.08,
//                           width: size.width * 0.20,
//                           // height: 70,
//                           // width:90,
//                           // margin: EdgeInsets.only(top:15),
//                           // padding: EdgeInsets.only(top: 10),
//                           padding: EdgeInsets.only(
//                               top: MediaQuery.of(context).size.width / 30),
//                           margin: EdgeInsets.only(
//                               top: MediaQuery.of(context).size.width / 30),
//                           decoration: BoxDecoration(
//                             color: Color(0xFFa8d5e5),
//                             border: Border.all(width: 0.3, color: Colors.grey),
//                             borderRadius: BorderRadius.circular(8),
//                           ),
//
//                           child: GestureDetector(
//                             onTap: () {
//                               Navigator.push(
//                                 context,
//                                 MaterialPageRoute(
//                                     builder: (context) => NokLogin()),
//                               );
//                             },
//                             child: Column(
//                               children: [
//                                 Container(
//
//                                   // height: 30
//                                   // ,width: 50,
//                                     height: size.height * 0.04,
//                                     width: size.width * 0.15,
//                                     child: Image(
//                                         image: AssetImage(
//                                             "assets/images/widow-icon.png"))),
//                                 Padding(
//                                   padding: EdgeInsets.symmetric(
//                                     horizontal:
//                                     MediaQuery.of(context).size.width / 40,
//                                     vertical:
//                                     MediaQuery.of(context).size.width / 200,
//                                   ),
//                                   // padding: EdgeInsets.only(left: MediaQuery.of(context).size.width/30),
//                                   child: AutoSizeText(
//                                     "NOK/WIDOW",
//                                     style: TextStyle(
//                                         color: Color(0xFF2c444d),
//                                         fontSize: 9,
//                                         fontWeight: FontWeight.bold),
//                                     minFontSize: 7,
//                                     maxFontSize: 9,
//                                     maxLines: 1,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ),
//                         Container(
//                           height: size.height * 0.08,
//                           width: size.width * 0.20,
//                           // height: 70,
//                           // width:90,
//                           // margin: EdgeInsets.only(top:15),
//                           // padding: EdgeInsets.only(top: 10),
//                           padding: EdgeInsets.only(
//                               top: MediaQuery.of(context).size.width / 30),
//                           margin: EdgeInsets.only(
//                               top: MediaQuery.of(context).size.width / 30),
//                           decoration: BoxDecoration(
//                             color: Color(0xFFa8d5e5),
//                             border: Border.all(width: 0.3, color: Colors.grey),
//                             borderRadius: BorderRadius.circular(8),
//                           ),
//
//                           child: GestureDetector(
//                             onTap: () {
//                               Navigator.push(
//                                 context,
//                                 MaterialPageRoute(
//                                     builder: (context) => Placement()),
//                               );
//                             },
//                             child: Column(
//                               children: [
//                                 Container(
//
//                                   // height: 30
//                                   // ,width: 50,
//                                     height: size.height * 0.04,
//                                     width: size.width * 0.15,
//                                     child: Image(
//                                         image: AssetImage(
//                                             "assets/images/placement-icon.png"))),
//                                 Padding(
//                                   padding: EdgeInsets.symmetric(
//                                     horizontal:
//                                     MediaQuery.of(context).size.width / 40,
//                                     vertical:
//                                     MediaQuery.of(context).size.width / 200,
//                                   ),
//                                   // padding:  EdgeInsets.only(left: MediaQuery.of(context).size.width/30),
//                                   child: AutoSizeText(
//                                     "PLACEMENT ",
//                                     style: TextStyle(
//                                         color: Color(0xFF2c444d),
//                                         fontSize: 9,
//                                         fontWeight: FontWeight.bold),
//                                     minFontSize: 7,
//                                     maxFontSize: 9,
//                                     maxLines: 1,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//             Padding(
//               padding:
//               EdgeInsets.only(top: MediaQuery.of(context).size.width / 200),
//               child: Container(
//                 // height: 280,
//                 // width: 320,
//                 height: size.height * 0.25,
//                 width: size.width * 0.89,
//                 child: Card(
//                   color: Color(0xFFf2fcff),
//                   child: Column(
//                     children: [
//                       Row(
//                         children: [
//                           Padding(
//                             padding: EdgeInsets.only(
//                                 left: MediaQuery.of(context).size.width / 30),
//                             child: Text(
//                               "Services",
//                               style: TextStyle(
//                                   fontSize: 20,
//                                   fontWeight: FontWeight.bold,
//                                   color: Color(0xFF474b50)),
//                             ),
//                           ),
//                         ],
//                       ),
//                       // Row(
//                       //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       //   children: [
//                       //     Container(
//                       //       height: size.height * 0.08,
//                       //       width: size.width * 0.20,
//                       //       // height: 70,
//                       //       // width:90,
//                       //       // margin: EdgeInsets.only(top:15),
//                       //       // padding: EdgeInsets.only(top: 10),
//                       //       padding: EdgeInsets.only(
//                       //           top: MediaQuery.of(context).size.width / 30),
//                       //       margin: EdgeInsets.only(
//                       //           top: MediaQuery.of(context).size.width / 100),
//                       //       decoration: BoxDecoration(
//                       //         // color: Colors.white,
//                       //         color: Color(0xFFd3eaf2),
//                       //         border:
//                       //         Border.all(width: 0.3, color: Colors.grey),
//                       //         borderRadius: BorderRadius.circular(8),
//                       //       ),
//                       //
//                       //       child: GestureDetector(
//                       //         onTap: () {
//                       //           Navigator.push(
//                       //             context,
//                       //             MaterialPageRoute(
//                       //                 builder: (context) => Update()),
//                       //           );
//                       //         },
//                       //         child: Column(
//                       //           children: [
//                       //             Container(
//                       //
//                       //               // height: 30
//                       //               // ,width: 50,
//                       //                 height: size.height * 0.03,
//                       //                 width: size.width * 0.15,
//                       //                 child: Image(
//                       //                     image: AssetImage(
//                       //                         "assets/images/update.png"))),
//                       //
//                       //             Padding(
//                       //               padding: EdgeInsets.symmetric(
//                       //                 horizontal:
//                       //                 MediaQuery.of(context).size.width /
//                       //                     30,
//                       //                 vertical:
//                       //                 MediaQuery.of(context).size.width /
//                       //                     50,
//                       //               ),
//                       //               child: AutoSizeText(
//                       //                 "UPDATES",
//                       //                 style: TextStyle(
//                       //                     color: Color(0xFF2c444d),
//                       //                     fontSize: 9,
//                       //                     fontWeight: FontWeight.bold),
//                       //                 minFontSize: 7,
//                       //                 maxFontSize: 9,
//                       //                 maxLines: 1,
//                       //               ),
//                       //             ),
//                       //           ],
//                       //         ),
//                       //       ),
//                       //     ),
//                       //     Container(
//                       //       height: size.height * 0.08,
//                       //       width: size.width * 0.20,
//                       //       // height: 70,
//                       //       // width:90,
//                       //       // margin: EdgeInsets.only(top:15),
//                       //       // padding: EdgeInsets.only(top: 10),
//                       //       padding: EdgeInsets.only(
//                       //           top: MediaQuery.of(context).size.width / 30),
//                       //       margin: EdgeInsets.only(
//                       //           top: MediaQuery.of(context).size.width / 130),
//                       //       decoration: BoxDecoration(
//                       //         color: Color(0xFFd3eaf2),
//                       //         // color: Colors.white,
//                       //         // color: Color(0xFFfec579),
//                       //         border:
//                       //         Border.all(width: 0.3, color: Colors.grey),
//                       //         borderRadius: BorderRadius.circular(8),
//                       //       ),
//                       //
//                       //       child: GestureDetector(
//                       //         onTap: () {},
//                       //         child: Column(
//                       //           children: [
//                       //             Container(
//                       //
//                       //               // height: 30
//                       //               // ,width: 50,
//                       //                 height: size.height * 0.03,
//                       //                 width: size.width * 0.10,
//                       //                 child: Image(
//                       //                     image: AssetImage(
//                       //                         "assets/images/bell.png"))),
//                       //
//                       //             Padding(
//                       //               padding: EdgeInsets.symmetric(
//                       //                 horizontal:
//                       //                 MediaQuery.of(context).size.width /
//                       //                     100,
//                       //                 vertical:
//                       //                 MediaQuery.of(context).size.width /
//                       //                     50,
//                       //               ),
//                       //               // padding:  EdgeInsets.only(left: MediaQuery.of(context).size.width/100),
//                       //               child: AutoSizeText(
//                       //                 "NOTIFICATION",
//                       //                 style: TextStyle(
//                       //                     color: Color(0xFF2c444d),
//                       //                     fontSize: 9,
//                       //                     fontWeight: FontWeight.bold),
//                       //                 minFontSize: 5,
//                       //                 maxFontSize: 8,
//                       //                 maxLines: 2,
//                       //               ),
//                       //             ),
//                       //           ],
//                       //         ),
//                       //       ),
//                       //     ),
//                       //     Container(
//                       //       height: size.height * 0.08,
//                       //       width: size.width * 0.20,
//                       //       // height: 70,
//                       //       // width:90,
//                       //       // margin: EdgeInsets.only(top:15),
//                       //       // padding: EdgeInsets.only(top: 10),
//                       //       padding: EdgeInsets.only(
//                       //           top: MediaQuery.of(context).size.width / 30),
//                       //       margin: EdgeInsets.only(
//                       //           top: MediaQuery.of(context).size.width / 130),
//                       //       decoration: BoxDecoration(
//                       //         color: Color(0xFFd3eaf2),
//                       //         // color: Colors.white,
//                       //         // color: Color(0xFFfec579),
//                       //         border:
//                       //         Border.all(width: 0.3, color: Colors.grey),
//                       //         borderRadius: BorderRadius.circular(8),
//                       //       ),
//                       //
//                       //       child: GestureDetector(
//                       //         onTap: () {},
//                       //         child: Column(
//                       //           children: [
//                       //             Container(
//                       //
//                       //               // height: 30
//                       //               // ,width: 50,
//                       //                 height: size.height * 0.03,
//                       //                 width: size.width * 0.15,
//                       //                 child: Image(
//                       //                     image: AssetImage(
//                       //                         "assets/images/video.png"))),
//                       //
//                       //             Padding(
//                       //               padding: EdgeInsets.symmetric(
//                       //                 horizontal:
//                       //                 MediaQuery.of(context).size.width /
//                       //                     90,
//                       //                 vertical:
//                       //                 MediaQuery.of(context).size.width /
//                       //                     200,
//                       //               ),
//                       //
//                       //               // padding:  EdgeInsets.only(left: MediaQuery.of(context).size.width/60),
//                       //               child: AutoSizeText(
//                       //                 "INFORMATION VIDEO",
//                       //                 style: TextStyle(
//                       //                     color: Color(0xFF2c444d),
//                       //                     fontSize: 9,
//                       //                     fontWeight: FontWeight.bold),
//                       //                 minFontSize: 5,
//                       //                 maxFontSize: 8,
//                       //                 maxLines: 2,
//                       //               ),
//                       //             ),
//                       //           ],
//                       //         ),
//                       //       ),
//                       //     ),
//                       //   ],
//                       // ),
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                         children: [
//                           Container(
//                             height: size.height * 0.08,
//                             width: size.width * 0.20,
//                             // height: 70,
//                             // width:90,
//                             // margin: EdgeInsets.only(top:15),
//                             // padding: EdgeInsets.only(top: 10),
//                             padding: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 30),
//                             margin: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 20),
//                             decoration: BoxDecoration(
//                               color: Color(0xFFd3eaf2),
//                               // color: Color(0xFFfec579),
//                               // color: Colors.white,
//                               border:
//                               Border.all(width: 0.3, color: Colors.grey),
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//
//                             child: GestureDetector(
//                               onTap: () {
//                                 Navigator.push(
//                                   context,
//                                   MaterialPageRoute(
//                                       builder: (context) => Servicepension()),
//                                 );
//                               },
//                               child: Column(
//                                 children: [
//                                   Container(
//
//                                     // height: 30
//                                     // ,width: 50,
//                                       height: size.height * 0.03,
//                                       width: size.width * 0.30,
//                                       child: Image(
//                                           image: AssetImage(
//                                               "assets/images/servicep.png"))),
//                                   Padding(
//                                     padding: EdgeInsets.only(
//                                         left:
//                                         MediaQuery.of(context).size.width /
//                                             30),
//                                     child: AutoSizeText(
//                                       "SERVICE PENSION",
//                                       style: TextStyle(
//                                           color: Color(0xFF2c444d),
//                                           fontSize: 9,
//                                           fontWeight: FontWeight.bold),
//                                       minFontSize: 6,
//                                       maxFontSize: 9,
//                                       maxLines: 2,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ),
//                           Container(
//                             height: size.height * 0.08,
//                             width: size.width * 0.20,
//                             // height: 70,
//                             // width:90,
//                             // margin: EdgeInsets.only(top:15),
//                             // padding: EdgeInsets.only(top: 10),
//                             padding: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 30),
//                             margin: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 20),
//                             decoration: BoxDecoration(
//                               color: Color(0xFFd3eaf2),
//                               // color: Color(0xFFfec579),
//                               // color: Colors.white,
//                               border:
//                               Border.all(width: 0.3, color: Colors.grey),
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//
//                             child: GestureDetector(
//                               onTap: () {
//                                 Navigator.push(
//                                   context,
//                                   MaterialPageRoute(
//                                       builder: (context) =>
//                                           Disabilitypension()),
//                                 );
//                               },
//                               child: Column(
//                                 children: [
//                                   Container(
//                                     //
//                                     // height: 30
//                                     // ,width: 50,
//                                       height: size.height * 0.03,
//                                       width: size.width * 0.2,
//                                       child: Image(
//                                           image: AssetImage(
//                                               "assets/images/disabilityp.png"))),
//                                   Padding(
//                                     padding: EdgeInsets.only(
//                                         left:
//                                         MediaQuery.of(context).size.width /
//                                             30),
//                                     child: AutoSizeText(
//                                       "DISABILITY PENSION",
//                                       style: TextStyle(
//                                           color: Color(0xFF2c444d),
//                                           fontSize: 9,
//                                           fontWeight: FontWeight.bold),
//                                       minFontSize: 6,
//                                       maxFontSize: 9,
//                                       maxLines: 2,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ),
//                           Container(
//                             height: size.height * 0.08,
//                             width: size.width * 0.20,
//                             // height: 70,
//                             // width:90,
//                             // margin: EdgeInsets.only(top:15),
//                             // padding: EdgeInsets.only(top: 10),
//                             padding: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 30),
//                             margin: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 20),
//                             decoration: BoxDecoration(
//                               color: Color(0xFFd3eaf2),
//                               // color: Colors.white,
//                               // color: Color(0xFFfec579),
//                               border:
//                               Border.all(width: 0.3, color: Colors.grey),
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//
//                             child: GestureDetector(
//                               onTap: () {
//                                 Navigator.push(
//                                   context,
//                                   MaterialPageRoute(
//                                       builder: (context) => Familypension()),
//                                 );
//                               },
//                               child: Column(
//                                 children: [
//                                   Container(
//
//                                     // height: 30
//                                     // ,width: 50,
//                                       height: size.height * 0.03,
//                                       width: size.width * 0.15,
//                                       child: Image(
//                                           image: AssetImage(
//                                               "assets/images/familyp.png"))),
//                                   Padding(
//                                     padding: EdgeInsets.only(
//                                         left:
//                                         MediaQuery.of(context).size.width /
//                                             30),
//                                     child: AutoSizeText(
//                                       "FAMILY PENSION",
//                                       style: TextStyle(
//                                           color: Color(0xFF2c444d),
//                                           fontSize: 9,
//                                           fontWeight: FontWeight.bold),
//                                       minFontSize: 6,
//                                       maxFontSize: 9,
//                                       maxLines: 2,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                         children: [
//                           Container(
//                             height: size.height * 0.08,
//                             width: size.width * 0.20,
//                             // height: 70,
//                             // width:90,
//                             // margin: EdgeInsets.only(top:15),
//                             // padding: EdgeInsets.only(top: 10),
//                             padding: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 30),
//                             margin: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 20),
//                             decoration: BoxDecoration(
//                               color: Color(0xFFd3eaf2),
//                               // color: Colors.white,
//                               // color: Color(0xFFfec579),
//                               border:
//                               Border.all(width: 0.3, color: Colors.grey),
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//
//                             child: GestureDetector(
//                               onTap: () {
//                                 Navigator.push(
//                                   context,
//                                   MaterialPageRoute(
//                                       builder: (context) => Welfare()),
//                                 );
//                               },
//                               child: Column(
//                                 children: [
//                                   Container(
//
//                                     // height: 30
//                                     // ,width: 50,
//                                       height: size.height * 0.03,
//                                       width: size.width * 0.15,
//                                       child: Image(
//                                           image: AssetImage(
//                                               "assets/images/welfare.png"))),
//                                   Padding(
//                                     padding: EdgeInsets.only(
//                                         left:
//                                         MediaQuery.of(context).size.width /
//                                             40),
//                                     child: AutoSizeText(
//                                       "ECHS & WELFARE ",
//                                       style: TextStyle(
//                                           color: Color(0xFF2c444d),
//                                           fontSize: 9,
//                                           fontWeight: FontWeight.bold),
//                                       minFontSize: 6,
//                                       maxFontSize: 9,
//                                       maxLines: 2,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ),
//                           Container(
//                             height: size.height * 0.08,
//                             width: size.width * 0.20,
//                             // height: 70,
//                             // width:90,
//                             // margin: EdgeInsets.only(top:15),
//                             // padding: EdgeInsets.only(top: 10),
//                             padding: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 30),
//                             margin: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 20),
//                             decoration: BoxDecoration(
//                               color: Color(0xFFd3eaf2),
//                               // color: Colors.white,
//                               // color: Color(0xFFfec579),
//                               border:
//                               Border.all(width: 0.3, color: Colors.grey),
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//
//                             child: GestureDetector(
//                               onTap: () {
//                                 Navigator.push(
//                                   context,
//                                   MaterialPageRoute(
//                                       builder: (context) => Ig6()),
//                                 );
//                               },
//                               child: Column(
//                                 children: [
//                                   Container(
//
//                                     // height: 30
//                                     // ,width: 50,
//                                       height: size.height * 0.038,
//                                       width: size.width * 0.15,
//                                       child: Image(
//                                           image: AssetImage(
//                                               "assets/images/bell.png"))),
//                                   Padding(
//                                     padding: EdgeInsets.only(
//                                         left:
//                                         MediaQuery.of(context).size.width /
//                                             180),
//                                     child: AutoSizeText(
//                                       "AFGIS",
//                                       style: TextStyle(
//                                           color: Color(0xFF2c444d),
//                                           fontSize: 9,
//                                           fontWeight: FontWeight.bold),
//                                       minFontSize: 4,
//                                       maxFontSize: 9,
//                                       maxLines: 1,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ),
//                           Container(
//                             height: size.height * 0.08,
//                             width: size.width * 0.20,
//                             // height: 70,
//                             // width:90,
//                             // margin: EdgeInsets.only(top:15),
//                             // padding: EdgeInsets.only(top: 10),
//                             padding: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 30),
//                             margin: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 20),
//                             decoration: BoxDecoration(
//                               color: Color(0xFFd3eaf2),
//                               // color: Colors.white,
//                               // color: Color(0xFFfec579),
//                               border:
//                               Border.all(width: 0.3, color: Colors.grey),
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//
//                             child: GestureDetector(
//                               onTap: () {
//                                 Navigator.push(
//                                   context,
//                                   MaterialPageRoute(
//                                       builder: (context) => Iafba()),
//                                 );
//                               },
//                               child: Column(
//                                 children: [
//                                   Container(
//
//                                     // height: 30
//                                     // ,width: 50,
//                                       height: size.height * 0.038,
//                                       width: size.width * 0.15,
//                                       child: Image(
//                                           image: AssetImage(
//                                               "assets/images/bell.png"))),
//                                   Padding(
//                                     padding: EdgeInsets.only(
//                                         left:
//                                         MediaQuery.of(context).size.width /
//                                             180),
//                                     child: AutoSizeText(
//                                       "IAFBA",
//                                       style: TextStyle(
//                                           color: Color(0xFF2c444d),
//                                           fontSize: 9,
//                                           fontWeight: FontWeight.bold),
//                                       minFontSize: 4,
//                                       maxFontSize: 9,
//                                       maxLines: 1,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//             Padding(
//               padding:
//               EdgeInsets.only(top: MediaQuery.of(context).size.width / 200),
//               child: Container(
//                 // height: 280,
//                 // width: 320,
//                 height: size.height * 0.25,
//                 width: size.width * 0.89,
//                 child: Card(
//                   color: Color(0xFFf2fcff),
//                   child: Column(
//                     children: [
//                       Row(
//                         children: [
//                           Padding(
//                             padding: EdgeInsets.only(
//                                 left: MediaQuery.of(context).size.width / 30),
//                             child: Text(
//                               "Informations",
//                               style: TextStyle(
//                                   fontSize: 20,
//                                   fontWeight: FontWeight.bold,
//                                   color: Color(0xFF474b50)),
//                             ),
//                           ),
//                         ],
//                       ),
//                       // Row(
//                       //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       //   children: [
//                       //     Container(
//                       //       height: size.height * 0.08,
//                       //       width: size.width * 0.20,
//                       //       // height: 70,
//                       //       // width:90,
//                       //       // margin: EdgeInsets.only(top:15),
//                       //       // padding: EdgeInsets.only(top: 10),
//                       //       padding: EdgeInsets.only(
//                       //           top: MediaQuery.of(context).size.width / 30),
//                       //       margin: EdgeInsets.only(
//                       //           top: MediaQuery.of(context).size.width / 100),
//                       //       decoration: BoxDecoration(
//                       //         // color: Colors.white,
//                       //         color: Color(0xFFd3eaf2),
//                       //         border:
//                       //         Border.all(width: 0.3, color: Colors.grey),
//                       //         borderRadius: BorderRadius.circular(8),
//                       //       ),
//                       //
//                       //       child: GestureDetector(
//                       //         onTap: () {
//                       //           Navigator.push(
//                       //             context,
//                       //             MaterialPageRoute(
//                       //                 builder: (context) => Update()),
//                       //           );
//                       //         },
//                       //         child: Column(
//                       //           children: [
//                       //             Container(
//                       //
//                       //               // height: 30
//                       //               // ,width: 50,
//                       //                 height: size.height * 0.03,
//                       //                 width: size.width * 0.15,
//                       //                 child: Image(
//                       //                     image: AssetImage(
//                       //                         "assets/images/update.png"))),
//                       //
//                       //             Padding(
//                       //               padding: EdgeInsets.symmetric(
//                       //                 horizontal:
//                       //                 MediaQuery.of(context).size.width /
//                       //                     30,
//                       //                 vertical:
//                       //                 MediaQuery.of(context).size.width /
//                       //                     50,
//                       //               ),
//                       //               child: AutoSizeText(
//                       //                 "UPDATES",
//                       //                 style: TextStyle(
//                       //                     color: Color(0xFF2c444d),
//                       //                     fontSize: 9,
//                       //                     fontWeight: FontWeight.bold),
//                       //                 minFontSize: 7,
//                       //                 maxFontSize: 9,
//                       //                 maxLines: 1,
//                       //               ),
//                       //             ),
//                       //           ],
//                       //         ),
//                       //       ),
//                       //     ),
//                       //     Container(
//                       //       height: size.height * 0.08,
//                       //       width: size.width * 0.20,
//                       //       // height: 70,
//                       //       // width:90,
//                       //       // margin: EdgeInsets.only(top:15),
//                       //       // padding: EdgeInsets.only(top: 10),
//                       //       padding: EdgeInsets.only(
//                       //           top: MediaQuery.of(context).size.width / 30),
//                       //       margin: EdgeInsets.only(
//                       //           top: MediaQuery.of(context).size.width / 130),
//                       //       decoration: BoxDecoration(
//                       //         color: Color(0xFFd3eaf2),
//                       //         // color: Colors.white,
//                       //         // color: Color(0xFFfec579),
//                       //         border:
//                       //         Border.all(width: 0.3, color: Colors.grey),
//                       //         borderRadius: BorderRadius.circular(8),
//                       //       ),
//                       //
//                       //       child: GestureDetector(
//                       //         onTap: () {},
//                       //         child: Column(
//                       //           children: [
//                       //             Container(
//                       //
//                       //               // height: 30
//                       //               // ,width: 50,
//                       //                 height: size.height * 0.03,
//                       //                 width: size.width * 0.10,
//                       //                 child: Image(
//                       //                     image: AssetImage(
//                       //                         "assets/images/bell.png"))),
//                       //
//                       //             Padding(
//                       //               padding: EdgeInsets.symmetric(
//                       //                 horizontal:
//                       //                 MediaQuery.of(context).size.width /
//                       //                     100,
//                       //                 vertical:
//                       //                 MediaQuery.of(context).size.width /
//                       //                     50,
//                       //               ),
//                       //               // padding:  EdgeInsets.only(left: MediaQuery.of(context).size.width/100),
//                       //               child: AutoSizeText(
//                       //                 "NOTIFICATION",
//                       //                 style: TextStyle(
//                       //                     color: Color(0xFF2c444d),
//                       //                     fontSize: 9,
//                       //                     fontWeight: FontWeight.bold),
//                       //                 minFontSize: 5,
//                       //                 maxFontSize: 8,
//                       //                 maxLines: 2,
//                       //               ),
//                       //             ),
//                       //           ],
//                       //         ),
//                       //       ),
//                       //     ),
//                       //     Container(
//                       //       height: size.height * 0.08,
//                       //       width: size.width * 0.20,
//                       //       // height: 70,
//                       //       // width:90,
//                       //       // margin: EdgeInsets.only(top:15),
//                       //       // padding: EdgeInsets.only(top: 10),
//                       //       padding: EdgeInsets.only(
//                       //           top: MediaQuery.of(context).size.width / 30),
//                       //       margin: EdgeInsets.only(
//                       //           top: MediaQuery.of(context).size.width / 130),
//                       //       decoration: BoxDecoration(
//                       //         color: Color(0xFFd3eaf2),
//                       //         // color: Colors.white,
//                       //         // color: Color(0xFFfec579),
//                       //         border:
//                       //         Border.all(width: 0.3, color: Colors.grey),
//                       //         borderRadius: BorderRadius.circular(8),
//                       //       ),
//                       //
//                       //       child: GestureDetector(
//                       //         onTap: () {},
//                       //         child: Column(
//                       //           children: [
//                       //             Container(
//                       //
//                       //               // height: 30
//                       //               // ,width: 50,
//                       //                 height: size.height * 0.03,
//                       //                 width: size.width * 0.15,
//                       //                 child: Image(
//                       //                     image: AssetImage(
//                       //                         "assets/images/video.png"))),
//                       //
//                       //             Padding(
//                       //               padding: EdgeInsets.symmetric(
//                       //                 horizontal:
//                       //                 MediaQuery.of(context).size.width /
//                       //                     90,
//                       //                 vertical:
//                       //                 MediaQuery.of(context).size.width /
//                       //                     200,
//                       //               ),
//                       //
//                       //               // padding:  EdgeInsets.only(left: MediaQuery.of(context).size.width/60),
//                       //               child: AutoSizeText(
//                       //                 "INFORMATION VIDEO",
//                       //                 style: TextStyle(
//                       //                     color: Color(0xFF2c444d),
//                       //                     fontSize: 9,
//                       //                     fontWeight: FontWeight.bold),
//                       //                 minFontSize: 5,
//                       //                 maxFontSize: 8,
//                       //                 maxLines: 2,
//                       //               ),
//                       //             ),
//                       //           ],
//                       //         ),
//                       //       ),
//                       //     ),
//                       //   ],
//                       // ),
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                         children: [
//                           Container(
//                             height: size.height * 0.08,
//                             width: size.width * 0.20,
//                             // height: 70,
//                             // width:90,
//                             // margin: EdgeInsets.only(top:15),
//                             // padding: EdgeInsets.only(top: 10),
//                             padding: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 30),
//                             margin: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 20),
//                             decoration: BoxDecoration(
//                               color: Color(0xFFd3eaf2),
//                               // color: Color(0xFFfec579),
//                               // color: Colors.white,
//                               border:
//                               Border.all(width: 0.3, color: Colors.grey),
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//
//                             child: GestureDetector(
//                               onTap: () {
//                                 Navigator.push(
//                                   context,
//                                   MaterialPageRoute(
//                                       builder: (context) => Update()),
//                                 );
//                               },
//                               child: Column(
//                                 children: [
//                                   Container(
//
//                                     // height: 30
//                                     // ,width: 50,
//                                       height: size.height * 0.03,
//                                       width: size.width * 0.30,
//                                       child: Image(
//                                           image: AssetImage(
//                                               "assets/images/update.png"))),
//                                   Padding(
//                                     padding: EdgeInsets.symmetric(
//                                       horizontal:
//                                       MediaQuery.of(context).size.width /
//                                           30,
//                                       vertical:
//                                       MediaQuery.of(context).size.width /
//                                           50,
//                                     ),
//                                     child: AutoSizeText(
//                                       "UPDATES",
//                                       style: TextStyle(
//                                           color: Color(0xFF2c444d),
//                                           fontSize: 9,
//                                           fontWeight: FontWeight.bold),
//                                       minFontSize: 7,
//                                       maxFontSize: 9,
//                                       maxLines: 1,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ),
//                           Container(
//                             height: size.height * 0.08,
//                             width: size.width * 0.20,
//                             // height: 70,
//                             // width:90,
//                             // margin: EdgeInsets.only(top:15),
//                             // padding: EdgeInsets.only(top: 10),
//                             padding: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 30),
//                             margin: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 20),
//                             decoration: BoxDecoration(
//                               color: Color(0xFFd3eaf2),
//                               // color: Color(0xFFfec579),
//                               // color: Colors.white,
//                               border:
//                               Border.all(width: 0.3, color: Colors.grey),
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//
//                             child: GestureDetector(
//                               // onTap: () {
//                               //   Navigator.push(
//                               //     context,
//                               //     MaterialPageRoute(
//                               //         builder: (context) =>
//                               //             Disabilitypension()),
//                               //   );
//                               // },
//                               child: Column(
//                                 children: [
//                                   Container(
//                                     //
//                                     // height: 30
//                                     // ,width: 50,
//                                       height: size.height * 0.03,
//                                       width: size.width * 0.2,
//                                       child: Image(
//                                           image: AssetImage(
//                                               "assets/images/bell.png"))),
//                                   Padding(
//                                     padding: EdgeInsets.symmetric(
//                                       horizontal:
//                                       MediaQuery.of(context).size.width /
//                                           100,
//                                       vertical:
//                                       MediaQuery.of(context).size.width /
//                                           50,
//                                     ),
//                                     child: AutoSizeText(
//                                       "NOTIFICATION",
//                                       style: TextStyle(
//                                           color: Color(0xFF2c444d),
//                                           fontSize: 9,
//                                           fontWeight: FontWeight.bold),
//                                       minFontSize: 5,
//                                       maxFontSize: 8,
//                                       maxLines: 2,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ),
//                           Container(
//                             height: size.height * 0.08,
//                             width: size.width * 0.20,
//                             // height: 70,
//                             // width:90,
//                             // margin: EdgeInsets.only(top:15),
//                             // padding: EdgeInsets.only(top: 10),
//                             padding: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 30),
//                             margin: EdgeInsets.only(
//                                 top: MediaQuery.of(context).size.width / 20),
//                             decoration: BoxDecoration(
//                               color: Color(0xFFd3eaf2),
//                               // color: Colors.white,
//                               // color: Color(0xFFfec579),
//                               border:
//                               Border.all(width: 0.3, color: Colors.grey),
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//
//                             child: GestureDetector(
//                               // onTap: () {
//                               //   Navigator.push(
//                               //     context,
//                               //     MaterialPageRoute(
//                               //         builder: (context) => ()),
//                               //   );
//                               // },
//                               child: Column(
//                                 children: [
//                                   Container(
//
//                                     // height: 30
//                                     // ,width: 50,
//                                       height: size.height * 0.03,
//                                       width: size.width * 0.15,
//                                       child: Image(
//                                           image: AssetImage(
//                                               "assets/images/video.png"))),
//                                   Padding(
//                                     padding: EdgeInsets.symmetric(
//                                       horizontal:
//                                       MediaQuery.of(context).size.width /
//                                           90,
//                                       vertical:
//                                       MediaQuery.of(context).size.width /
//                                           200,
//                                     ),
//                                     child: AutoSizeText(
//                                       "INFORMATION VIDEO",
//                                       style: TextStyle(
//                                           color: Color(0xFF2c444d),
//                                           fontSize: 9,
//                                           fontWeight: FontWeight.bold),
//                                       minFontSize: 5,
//                                       maxFontSize: 8,
//                                       maxLines: 2,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                       Row(
//
//                         children: [
//                           Padding(
//                             padding: EdgeInsets.only(
//                                 left: MediaQuery.of(context).size.width / 15),
//                             child: Container(
//                               height: size.height * 0.08,
//                               width: size.width * 0.20,
//                               // height: 70,
//                               // width:90,
//                               // margin: EdgeInsets.only(top:15),
//                               // padding: EdgeInsets.only(top: 10),
//                               padding: EdgeInsets.only(
//                                   top: MediaQuery.of(context).size.width / 30),
//                               margin: EdgeInsets.only(
//                                   top: MediaQuery.of(context).size.width / 20),
//                               decoration: BoxDecoration(
//                                 color: Color(0xFFd3eaf2),
//                                 // color: Colors.white,
//                                 // color: Color(0xFFfec579),
//                                 border:
//                                 Border.all(width: 0.3, color: Colors.grey),
//                                 borderRadius: BorderRadius.circular(8),
//                               ),
//
//                               child: GestureDetector(
//                                 onTap: () {
//                                   Navigator.push(
//                                     context,
//                                     MaterialPageRoute(
//                                         builder: (context) => Resettlement()),
//                                   );
//                                 },
//                                 child: Column(
//                                   children: [
//                                     Container(
//
//                                       // height: 30
//                                       // ,width: 50,
//                                         height: size.height * 0.038,
//                                         width: size.width * 0.15,
//                                         child: Image(
//                                             image: AssetImage(
//                                                 "assets/images/resettlement.png"))),
//                                     Padding(
//                                       padding: EdgeInsets.only(
//                                           left:
//                                           MediaQuery.of(context).size.width /
//                                               80),
//                                       child: AutoSizeText(
//                                         "RESETTLEMENT",
//                                         style: TextStyle(
//                                             color: Color(0xFF2c444d),
//                                             fontSize: 9,
//                                             fontWeight: FontWeight.bold),
//                                         minFontSize: 4,
//                                         maxFontSize: 8,
//                                         maxLines: 2,
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             ),
//                           ),
//                           Padding(
//                             padding:  EdgeInsets.only(
//                                 left: MediaQuery.of(context).size.width / 15),
//                             child: Container(
//                               height: size.height * 0.08,
//                               width: size.width * 0.20,
//                               // height: 70,
//                               // width:90,
//                               // margin: EdgeInsets.only(top:15),
//                               // padding: EdgeInsets.only(top: 10),
//                               padding: EdgeInsets.only(
//                                   top: MediaQuery.of(context).size.width / 30),
//                               margin: EdgeInsets.only(
//                                   top: MediaQuery.of(context).size.width / 20),
//                               decoration: BoxDecoration(
//                                 color: Color(0xFFd3eaf2),
//                                 // color: Colors.white,
//                                 // color: Color(0xFFfec579),
//                                 border:
//                                 Border.all(width: 0.3, color: Colors.grey),
//                                 borderRadius: BorderRadius.circular(8),
//                               ),
//
//                               child: GestureDetector(
//                                 onTap: () {
//                                   Navigator.push(
//                                     context,
//                                     MaterialPageRoute(
//                                         builder: (context) => Faq()),
//                                   );
//                                 },
//                                 child: Column(
//                                   children: [
//                                     Container(
//                                       //
//                                       // height: 30
//                                       // ,width: 50,
//                                         height: size.height * 0.03,
//                                         width: size.width * 0.15,
//                                         child: Image(
//                                             image: AssetImage(
//                                                 "assets/images/faq.png"))),
//                                     Padding(
//                                       padding: EdgeInsets.symmetric(
//                                         horizontal:
//                                         MediaQuery.of(context).size.width /
//                                             30,
//                                         vertical:
//                                         MediaQuery.of(context).size.width /
//                                             50,
//                                       ),
//                                       child: AutoSizeText(
//                                         "FAQs",
//                                         style: TextStyle(
//                                             color: Color(0xFF2c444d),
//                                             fontSize: 9,
//                                             fontWeight: FontWeight.bold),
//                                         minFontSize: 7,
//                                         maxFontSize: 9,
//                                         maxLines: 1,
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             ),
//                           ),
//
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//             // Padding(
//             //   padding:
//             //       EdgeInsets.only(top: MediaQuery.of(context).size.width / 200),
//             //   child: Container(
//             //     // height: 280,
//             //     // width: 320,
//             //     height: size.height * 0.25,
//             //     width: size.width * 0.89,
//             //     child: Card(
//             //       color: Color(0xFFf2fcff),
//             //       child: Column(
//             //         children: [
//             //           Row(
//             //             children: [
//             //               Padding(
//             //                 padding: EdgeInsets.only(
//             //                     left: MediaQuery.of(context).size.width / 30),
//             //
//             //                 child: Text(
//             //
//             //                   "Informations",
//             //                   style: TextStyle(
//             //                       fontSize: 19,
//             //                       fontWeight: FontWeight.bold,
//             //                       color: Color(0xFF474b50)),
//             //                 ),
//             //               ),
//             //             ],
//             //           ),
//             //           // Row(
//             //           //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//             //           //   children: [
//             //           //     Container(
//             //           //       height: size.height * 0.08,
//             //           //       width: size.width * 0.20,
//             //           //       // height: 70,
//             //           //       // width:90,
//             //           //       // margin: EdgeInsets.only(top:15),
//             //           //       // padding: EdgeInsets.only(top: 10),
//             //           //       padding: EdgeInsets.only(
//             //           //           top: MediaQuery.of(context).size.width / 30),
//             //           //       margin: EdgeInsets.only(
//             //           //           top: MediaQuery.of(context).size.width / 100),
//             //           //       decoration: BoxDecoration(
//             //           //         // color: Colors.white,
//             //           //         color: Color(0xFFd3eaf2),
//             //           //         border:
//             //           //         Border.all(width: 0.3, color: Colors.grey),
//             //           //         borderRadius: BorderRadius.circular(8),
//             //           //       ),
//             //           //
//             //           //       child: GestureDetector(
//             //           //         onTap: () {
//             //           //           Navigator.push(
//             //           //             context,
//             //           //             MaterialPageRoute(
//             //           //                 builder: (context) => Update()),
//             //           //           );
//             //           //         },
//             //           //         child: Column(
//             //           //           children: [
//             //           //             Container(
//             //           //
//             //           //               // height: 30
//             //           //               // ,width: 50,
//             //           //                 height: size.height * 0.03,
//             //           //                 width: size.width * 0.15,
//             //           //                 child: Image(
//             //           //                     image: AssetImage(
//             //           //                         "assets/images/update.png"))),
//             //           //
//             //           //             Padding(
//             //           //               padding: EdgeInsets.symmetric(
//             //           //                 horizontal:
//             //           //                 MediaQuery.of(context).size.width /
//             //           //                     30,
//             //           //                 vertical:
//             //           //                 MediaQuery.of(context).size.width /
//             //           //                     50,
//             //           //               ),
//             //           //               child: AutoSizeText(
//             //           //                 "UPDATES",
//             //           //                 style: TextStyle(
//             //           //                     color: Color(0xFF2c444d),
//             //           //                     fontSize: 9,
//             //           //                     fontWeight: FontWeight.bold),
//             //           //                 minFontSize: 7,
//             //           //                 maxFontSize: 9,
//             //           //                 maxLines: 1,
//             //           //               ),
//             //           //             ),
//             //           //           ],
//             //           //         ),
//             //           //       ),
//             //           //     ),
//             //           //     Container(
//             //           //       height: size.height * 0.08,
//             //           //       width: size.width * 0.20,
//             //           //       // height: 70,
//             //           //       // width:90,
//             //           //       // margin: EdgeInsets.only(top:15),
//             //           //       // padding: EdgeInsets.only(top: 10),
//             //           //       padding: EdgeInsets.only(
//             //           //           top: MediaQuery.of(context).size.width / 30),
//             //           //       margin: EdgeInsets.only(
//             //           //           top: MediaQuery.of(context).size.width / 130),
//             //           //       decoration: BoxDecoration(
//             //           //         color: Color(0xFFd3eaf2),
//             //           //         // color: Colors.white,
//             //           //         // color: Color(0xFFfec579),
//             //           //         border:
//             //           //         Border.all(width: 0.3, color: Colors.grey),
//             //           //         borderRadius: BorderRadius.circular(8),
//             //           //       ),
//             //           //
//             //           //       child: GestureDetector(
//             //           //         onTap: () {},
//             //           //         child: Column(
//             //           //           children: [
//             //           //             Container(
//             //           //
//             //           //               // height: 30
//             //           //               // ,width: 50,
//             //           //                 height: size.height * 0.03,
//             //           //                 width: size.width * 0.10,
//             //           //                 child: Image(
//             //           //                     image: AssetImage(
//             //           //                         "assets/images/bell.png"))),
//             //           //
//             //           //             Padding(
//             //           //               padding: EdgeInsets.symmetric(
//             //           //                 horizontal:
//             //           //                 MediaQuery.of(context).size.width /
//             //           //                     100,
//             //           //                 vertical:
//             //           //                 MediaQuery.of(context).size.width /
//             //           //                     50,
//             //           //               ),
//             //           //               // padding:  EdgeInsets.only(left: MediaQuery.of(context).size.width/100),
//             //           //               child: AutoSizeText(
//             //           //                 "NOTIFICATION",
//             //           //                 style: TextStyle(
//             //           //                     color: Color(0xFF2c444d),
//             //           //                     fontSize: 9,
//             //           //                     fontWeight: FontWeight.bold),
//             //           //                 minFontSize: 5,
//             //           //                 maxFontSize: 8,
//             //           //                 maxLines: 2,
//             //           //               ),
//             //           //             ),
//             //           //           ],
//             //           //         ),
//             //           //       ),
//             //           //     ),
//             //           //     Container(
//             //           //       height: size.height * 0.08,
//             //           //       width: size.width * 0.20,
//             //           //       // height: 70,
//             //           //       // width:90,
//             //           //       // margin: EdgeInsets.only(top:15),
//             //           //       // padding: EdgeInsets.only(top: 10),
//             //           //       padding: EdgeInsets.only(
//             //           //           top: MediaQuery.of(context).size.width / 30),
//             //           //       margin: EdgeInsets.only(
//             //           //           top: MediaQuery.of(context).size.width / 130),
//             //           //       decoration: BoxDecoration(
//             //           //         color: Color(0xFFd3eaf2),
//             //           //         // color: Colors.white,
//             //           //         // color: Color(0xFFfec579),
//             //           //         border:
//             //           //         Border.all(width: 0.3, color: Colors.grey),
//             //           //         borderRadius: BorderRadius.circular(8),
//             //           //       ),
//             //           //
//             //           //       child: GestureDetector(
//             //           //         onTap: () {},
//             //           //         child: Column(
//             //           //           children: [
//             //           //             Container(
//             //           //
//             //           //               // height: 30
//             //           //               // ,width: 50,
//             //           //                 height: size.height * 0.03,
//             //           //                 width: size.width * 0.15,
//             //           //                 child: Image(
//             //           //                     image: AssetImage(
//             //           //                         "assets/images/video.png"))),
//             //           //
//             //           //             Padding(
//             //           //               padding: EdgeInsets.symmetric(
//             //           //                 horizontal:
//             //           //                 MediaQuery.of(context).size.width /
//             //           //                     90,
//             //           //                 vertical:
//             //           //                 MediaQuery.of(context).size.width /
//             //           //                     200,
//             //           //               ),
//             //           //
//             //           //               // padding:  EdgeInsets.only(left: MediaQuery.of(context).size.width/60),
//             //           //               child: AutoSizeText(
//             //           //                 "INFORMATION VIDEO",
//             //           //                 style: TextStyle(
//             //           //                     color: Color(0xFF2c444d),
//             //           //                     fontSize: 9,
//             //           //                     fontWeight: FontWeight.bold),
//             //           //                 minFontSize: 5,
//             //           //                 maxFontSize: 8,
//             //           //                 maxLines: 2,
//             //           //               ),
//             //           //             ),
//             //           //           ],
//             //           //         ),
//             //           //       ),
//             //           //     ),
//             //           //   ],
//             //           // ),
//             //           Row(
//             //             mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//             //             children: [
//             //               Container(
//             //                 height: size.height * 0.08,
//             //                 width: size.width * 0.20,
//             //                 // height: 70,
//             //                 // width:90,
//             //                 // margin: EdgeInsets.only(top:15),
//             //                 // padding: EdgeInsets.only(top: 10),
//             //                 padding: EdgeInsets.only(
//             //                     top: MediaQuery.of(context).size.width / 30),
//             //                 margin: EdgeInsets.only(
//             //                     top: MediaQuery.of(context).size.width / 100),
//             //                 decoration: BoxDecoration(
//             //                   // color: Colors.white,
//             //                   color: Color(0xFFd3eaf2),
//             //                   border:
//             //                       Border.all(width: 0.3, color: Colors.grey),
//             //                   borderRadius: BorderRadius.circular(8),
//             //                 ),
//             //
//             //                 child: GestureDetector(
//             //                   onTap: () {
//             //                     Navigator.push(
//             //                       context,
//             //                       MaterialPageRoute(
//             //                           builder: (context) => Update()),
//             //                     );
//             //                   },
//             //                   child: Column(
//             //                     children: [
//             //                       Container(
//             //
//             //                           // height: 30
//             //                           // ,width: 50,
//             //                           height: size.height * 0.03,
//             //                           width: size.width * 0.15,
//             //                           child: Image(
//             //                               image: AssetImage(
//             //                                   "assets/images/update.png"))),
//             //                       Padding(
//             //                         padding: EdgeInsets.symmetric(
//             //                           horizontal:
//             //                               MediaQuery.of(context).size.width /
//             //                                   30,
//             //                           vertical:
//             //                               MediaQuery.of(context).size.width /
//             //                                   50,
//             //                         ),
//             //                         child: AutoSizeText(
//             //                           "UPDATES",
//             //                           style: TextStyle(
//             //                               color: Color(0xFF2c444d),
//             //                               fontSize: 9,
//             //                               fontWeight: FontWeight.bold),
//             //                           minFontSize: 7,
//             //                           maxFontSize: 9,
//             //                           maxLines: 1,
//             //                         ),
//             //                       ),
//             //                     ],
//             //                   ),
//             //                 ),
//             //               ),
//             //               Container(
//             //                 height: size.height * 0.08,
//             //                 width: size.width * 0.20,
//             //                 // height: 70,
//             //                 // width:90,
//             //                 // margin: EdgeInsets.only(top:15),
//             //                 // padding: EdgeInsets.only(top: 10),
//             //                 padding: EdgeInsets.only(
//             //                     top: MediaQuery.of(context).size.width / 30),
//             //                 margin: EdgeInsets.only(
//             //                     top: MediaQuery.of(context).size.width / 130),
//             //                 decoration: BoxDecoration(
//             //                   color: Color(0xFFd3eaf2),
//             //                   // color: Colors.white,
//             //                   // color: Color(0xFFfec579),
//             //                   border:
//             //                       Border.all(width: 0.3, color: Colors.grey),
//             //                   borderRadius: BorderRadius.circular(8),
//             //                 ),
//             //
//             //                 child: GestureDetector(
//             //                   onTap: () {},
//             //                   child: Column(
//             //                     children: [
//             //                       Container(
//             //
//             //                           // height: 30
//             //                           // ,width: 50,
//             //                           height: size.height * 0.03,
//             //                           width: size.width * 0.10,
//             //                           child: Image(
//             //                               image: AssetImage(
//             //                                   "assets/images/bell.png"))),
//             //                       Padding(
//             //                         padding: EdgeInsets.symmetric(
//             //                           horizontal:
//             //                               MediaQuery.of(context).size.width /
//             //                                   100,
//             //                           vertical:
//             //                               MediaQuery.of(context).size.width /
//             //                                   50,
//             //                         ),
//             //                         // padding:  EdgeInsets.only(left: MediaQuery.of(context).size.width/100),
//             //                         child: AutoSizeText(
//             //                           "NOTIFICATION",
//             //                           style: TextStyle(
//             //                               color: Color(0xFF2c444d),
//             //                               fontSize: 9,
//             //                               fontWeight: FontWeight.bold),
//             //                           minFontSize: 5,
//             //                           maxFontSize: 8,
//             //                           maxLines: 2,
//             //                         ),
//             //                       ),
//             //                     ],
//             //                   ),
//             //                 ),
//             //               ),
//             //               Container(
//             //                 height: size.height * 0.08,
//             //                 width: size.width * 0.20,
//             //                 // height: 70,
//             //                 // width:90,
//             //                 // margin: EdgeInsets.only(top:15),
//             //                 // padding: EdgeInsets.only(top: 10),
//             //                 padding: EdgeInsets.only(
//             //                     top: MediaQuery.of(context).size.width / 30),
//             //                 margin: EdgeInsets.only(
//             //                     top: MediaQuery.of(context).size.width / 130),
//             //                 decoration: BoxDecoration(
//             //                   color: Color(0xFFd3eaf2),
//             //                   // color: Colors.white,
//             //                   // color: Color(0xFFfec579),
//             //                   border:
//             //                       Border.all(width: 0.3, color: Colors.grey),
//             //                   borderRadius: BorderRadius.circular(8),
//             //                 ),
//             //
//             //                 child: GestureDetector(
//             //                   onTap: () {},
//             //                   child: Column(
//             //                     children: [
//             //                       Container(
//             //
//             //                           // height: 30
//             //                           // ,width: 50,
//             //                           height: size.height * 0.03,
//             //                           width: size.width * 0.15,
//             //                           child: Image(
//             //                               image: AssetImage(
//             //                                   "assets/images/video.png"))),
//             //                       Padding(
//             //                         padding: EdgeInsets.symmetric(
//             //                           horizontal:
//             //                               MediaQuery.of(context).size.width /
//             //                                   90,
//             //                           vertical:
//             //                               MediaQuery.of(context).size.width /
//             //                                   200,
//             //                         ),
//             //
//             //                         // padding:  EdgeInsets.only(left: MediaQuery.of(context).size.width/60),
//             //                         child: AutoSizeText(
//             //                           "INFORMATION VIDEO",
//             //                           style: TextStyle(
//             //                               color: Color(0xFF2c444d),
//             //                               fontSize: 9,
//             //                               fontWeight: FontWeight.bold),
//             //                           minFontSize: 5,
//             //                           maxFontSize: 8,
//             //                           maxLines: 2,
//             //                         ),
//             //                       ),
//             //                     ],
//             //                   ),
//             //                 ),
//             //               ),
//             //             ],
//             //           ),
//             //           Row(
//             //             mainAxisAlignment: MainAxisAlignment.start,
//             //
//             //             children: [
//             //               Padding(
//             //                 padding: EdgeInsets.only(
//             //                     left: MediaQuery.of(context).size.width / 15),
//             //                 child: Container(
//             //                   height: size.height * 0.08,
//             //                   width: size.width * 0.20,
//             //                   // height: 70,
//             //                   // width:90,
//             //                   // margin: EdgeInsets.only(top:15),
//             //                   // padding: EdgeInsets.only(top: 10),
//             //                   padding: EdgeInsets.only(
//             //                       top: MediaQuery.of(context).size.width / 30),
//             //                   margin: EdgeInsets.only(
//             //                       top: MediaQuery.of(context).size.width / 20),
//             //                   decoration: BoxDecoration(
//             //                     color: Color(0xFFd3eaf2),
//             //                     // color: Colors.white,
//             //                     // color: Color(0xFFfec579),
//             //                     border:
//             //                         Border.all(width: 0.3, color: Colors.grey),
//             //                     borderRadius: BorderRadius.circular(8),
//             //                   ),
//             //
//             //                   child: GestureDetector(
//             //                     onTap: () {
//             //                       Navigator.push(
//             //                         context,
//             //                         MaterialPageRoute(
//             //                             builder: (context) => Resettlement()),
//             //                       );
//             //                     },
//             //                     child: Column(
//             //                       children: [
//             //                         Container(
//             //
//             //                             // height: 30
//             //                             // ,width: 50,
//             //                             height: size.height * 0.038,
//             //                             width: size.width * 0.15,
//             //                             child: Image(
//             //                                 image: AssetImage(
//             //                                     "assets/images/resettlement.png"))),
//             //                         Padding(
//             //                           padding: EdgeInsets.only(
//             //                               left:
//             //                                   MediaQuery.of(context).size.width /
//             //                                       80),
//             //                           child: AutoSizeText(
//             //                             "RESETTLEMENT",
//             //                             style: TextStyle(
//             //                                 color: Color(0xFF2c444d),
//             //                                 fontSize: 9,
//             //                                 fontWeight: FontWeight.bold),
//             //                             minFontSize: 4,
//             //                             maxFontSize: 8,
//             //                             maxLines: 2,
//             //                           ),
//             //                         ),
//             //                       ],
//             //                     ),
//             //                   ),
//             //                 ),
//             //               ),
//             //               Padding(
//             //                 padding: EdgeInsets.only(
//             //                     left: MediaQuery.of(context).size.width / 15),
//             //                 child: Container(
//             //                   height: size.height * 0.08,
//             //                   width: size.width * 0.20,
//             //                   // height: 70,
//             //                   // width:90,
//             //                   // margin: EdgeInsets.only(top:15),
//             //                   // padding: EdgeInsets.only(top: 10),
//             //                   padding: EdgeInsets.only(
//             //                       top: MediaQuery.of(context).size.width / 30),
//             //                   margin: EdgeInsets.only(
//             //                       top: MediaQuery.of(context).size.width / 20),
//             //                   decoration: BoxDecoration(
//             //                     color: Color(0xFFd3eaf2),
//             //                     // color: Colors.white,
//             //                     // color: Color(0xFFfec579),
//             //                     border:
//             //                         Border.all(width: 0.3, color: Colors.grey),
//             //                     borderRadius: BorderRadius.circular(8),
//             //                   ),
//             //
//             //                   child: GestureDetector(
//             //                     onTap: () {
//             //                       Navigator.push(
//             //                         context,
//             //                         MaterialPageRoute(
//             //                             builder: (context) => Faq()),
//             //                       );
//             //                     },
//             //                     child: Column(
//             //                       children: [
//             //                         Container(
//             //                             //
//             //                             // height: 30
//             //                             // ,width: 50,
//             //                             height: size.height * 0.03,
//             //                             width: size.width * 0.15,
//             //                             child: Image(
//             //                                 image: AssetImage(
//             //                                     "assets/images/faq.png"))),
//             //                         Padding(
//             //                           padding: EdgeInsets.symmetric(
//             //                             horizontal:
//             //                                 MediaQuery.of(context).size.width /
//             //                                     30,
//             //                             vertical:
//             //                                 MediaQuery.of(context).size.width /
//             //                                     50,
//             //                           ),
//             //                           child: AutoSizeText(
//             //                             "FAQs",
//             //                             style: TextStyle(
//             //                                 color: Color(0xFF2c444d),
//             //                                 fontSize: 9,
//             //                                 fontWeight: FontWeight.bold),
//             //                             minFontSize: 7,
//             //                             maxFontSize: 9,
//             //                             maxLines: 1,
//             //                           ),
//             //                         ),
//             //                       ],
//             //                     ),
//             //                   ),
//             //                 ),
//             //               ),
//             //             ],
//             //           ),
//             //         ],
//             //       ),
//             //     ),
//             //   ),
//             //
//             // ),
//             Container(
//               // margin: EdgeInsets.only(top: 30.0),
//
//               margin:
//               EdgeInsets.only(top: MediaQuery.of(context).size.width / 70),
//               // height: 65,
//               height: size.height * 0.07,
//               decoration: BoxDecoration(
//                   borderRadius: BorderRadius.circular(8),
//                   gradient: LinearGradient(
//                       begin: Alignment.topLeft,
//                       end: Alignment.bottomRight,
//                       stops: [0.3, 1],
//                       colors: [Color(0xFF394361), Color(0xFFa8d5e5)])),
//               child: CarouselSlider(
//                 items: [
//                   Padding(
//                     padding: EdgeInsets.only(
//                         top: MediaQuery.of(context).size.width / 400),
//                     child: GestureDetector(
//                       onTap: () {
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(builder: (context) => Ig1()),
//                         );
//                       },
//                       // onTap: () =>
//                       //     launchUrl(Uri.parse('  http://www.ksb.gov.in/')),
//                       child: Container(
//                         // height: 30,
//                         // width: 150,
//                         height: size.height * 0.09,
//                         width: size.width * 0.25,
//                         decoration: BoxDecoration(
//                           image: DecorationImage(
//                             image: AssetImage("assets/images/Img1.1.png"),
//                             // fit: BoxFit.cover,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(
//                         top: MediaQuery.of(context).size.width / 300),
//                     child: GestureDetector(
//                       onTap: () {
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(builder: (context) => Ig2()),
//                         );
//                       },
//                       // onTap: () =>
//                       //     launchUrl(Uri.parse('https://www.india.gov.in/')),
//                       child: Container(
//                         // height: 30,
//                         // width: 150,
//                         height: size.height * 0.09,
//                         width: size.width * 0.25,
//                         decoration: BoxDecoration(
//                           image: DecorationImage(
//                             image: AssetImage("assets/images/Img2.png"),
//                             // fit: BoxFit.cover,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                   Padding(
//                     padding: const EdgeInsets.only(top: 10.0),
//                     child: GestureDetector(
//                       onTap: () {
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(builder: (context) => Ig3()),
//                         );
//                       },
//                       // onTap: () => launchUrl(
//                       //     Uri.parse('https://indianairforce.nic.in/')),
//                       child: Container(
//                         // height:30,
//                         // width: 150,
//                         height: size.height * 0.09,
//                         width: size.width * 0.25,
//                         decoration: BoxDecoration(
//                           image: DecorationImage(
//                             image: AssetImage("assets/images/Img3.png"),
//                             // fit: BoxFit.cover,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(
//                         top: MediaQuery.of(context).size.width / 300),
//                     child: GestureDetector(
//                       onTap: () {
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(builder: (context) => Ig4()),
//                         );
//                       },
//                       // onTap: () => launchUrl(Uri.parse(
//                       //     'https://joinindianarmy.nic.in/default.aspx')),
//                       child: Container(
//                         // height: 30,
//                         // width: 150,
//                         height: size.height * 0.09,
//                         width: size.width * 0.25,
//                         decoration: BoxDecoration(
//                           image: DecorationImage(
//                             image: AssetImage("assets/images/Img4.jpg"),
//                             // fit: BoxFit.cover,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(
//                         top: MediaQuery.of(context).size.width / 300),
//                     child: GestureDetector(
//                       onTap: () {
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(builder: (context) => Ig5()),
//                         );
//                       },
//
//                       // onTap: () => launchUrl(
//                       //     Uri.parse('https://www.joinindiannavy.gov.in/')),
//                       child: Container(
//                         // height: 30,
//                         // width: 150,
//                         height: size.height * 0.09,
//                         width: size.width * 0.25,
//                         decoration: BoxDecoration(
//                           image: DecorationImage(
//                             image: AssetImage("assets/images/Img5.png"),
//                             // fit: BoxFit.cover,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(
//                         top: MediaQuery.of(context).size.width / 300),
//                     child: GestureDetector(
//                       onTap: () {
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(builder: (context) => Ig6()),
//                         );
//                       },
//                       // onTap: () => launchUrl(Uri.parse(
//                       //     'https://iafpensioners.gov.in/ords/dav_portal/r/afgis/home')),
//                       child: Container(
//                         // height: 30,
//                         // width: 150,
//                         height: size.height * 0.09,
//                         width: size.width * 0.25,
//                         decoration: BoxDecoration(
//                           image: DecorationImage(
//                             image: AssetImage("assets/images/Img6.png"),
//                             // fit: BoxFit.cover,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(
//                         top: MediaQuery.of(context).size.width / 300),
//                     child: GestureDetector(
//                       onTap: () {
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(builder: (context) => Ig7()),
//                         );
//                       },
//                       // onTap: () => launchUrl(Uri.parse(
//                       //     'https://iafpensioners.gov.in/ords/dav_portal/r/dte_av/useful-links?p0_title=OTHER%20LINKS')),
//                       child: Container(
//                         // height: 30,
//                         // width: 150,
//                         height: size.height * 0.09,
//                         width: size.width * 0.25,
//                         decoration: BoxDecoration(
//                           image: DecorationImage(
//                             image: AssetImage("assets/images/Img7.png"),
//                             // fit: BoxFit.cover,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(
//                         top: MediaQuery.of(context).size.width / 300),
//                     child: GestureDetector(
//                       onTap: () {
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(builder: (context) => Ig8()),
//                         );
//                       },
//                       // onTap: () =>
//                       //     launchUrl(Uri.parse('https://www.mygov.in/')),
//                       child: Container(
//                         // height: 30,
//                         // width: 150,
//                         height: size.height * 0.09,
//                         width: size.width * 0.25,
//                         decoration: BoxDecoration(
//                           image: DecorationImage(
//                             image: AssetImage("assets/images/Img8.jpg"),
//                             // fit: BoxFit.cover,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(
//                         top: MediaQuery.of(context).size.width / 300),
//                     child: GestureDetector(
//                       onTap: () {
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(builder: (context) => Ig9()),
//                         );
//                       },
//                       // onTap: () =>
//                       //     launchUrl(Uri.parse('https://www.desw.gov.in/')),
//                       child: Container(
//                         // height: 30,
//                         // width: 150,
//                         height: size.height * 0.09,
//                         width: size.width * 0.25,
//                         decoration: BoxDecoration(
//                           image: DecorationImage(
//                             image: AssetImage("assets/images/Img9.png"),
//                             // fit: BoxFit.cover,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//                 options: CarouselOptions(
//                   height: size.height * 0.04,
//                   enlargeCenterPage: false,
//                   autoPlay: true,
//                   aspectRatio: 16 / 9,
//                   autoPlayCurve: Curves.fastOutSlowIn,
//                   enableInfiniteScroll: true,
//                   autoPlayAnimationDuration: Duration(milliseconds: 5),
//                   viewportFraction: 0.3,
//                 ),
//               ),
//             ),
//           ],
//         ),
//
//       ),
//
//     );
//
//   }
//
//   void toggleRecording() {
//
//     SpeechApi.toggleRecording(
//       onResult: (String text) => setState(() => this.text=text),
//
//     );
//   }
// }
//
// // code to give blue shades to icons nd background
// // or have to use icon with orange bg color
