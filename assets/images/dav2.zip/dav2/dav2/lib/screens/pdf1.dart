import 'package:dav2/Models/service_models/dataservice.dart';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

class pdf1 extends StatefulWidget {
  var url = "";
  pdf1(this.url);

  @override
  State<pdf1> createState() => PdfState();
}

class PdfState extends State<pdf1> {
  String? localPath;
  Future<Service>? futureAlbum;

  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xFF394361),
          title: Text(
            "SERVING THOSE WHO SERVED US",
            style: TextStyle(fontSize: 15),
          ),
        ),
        body: SfPdfViewer.network(widget.url));
  }
}
