import 'dart:ui';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:carousel_slider/carousel_options.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:dav2/screens/Servicehome.dart';
import 'package:dav2/screens/Updateshome.dart';
import 'package:dav2/screens/disabilityhome.dart';
import 'package:dav2/screens/echshome.dart';
import 'package:dav2/screens/echsmap.dart';
import 'package:dav2/screens/eppo.dart';
import 'package:dav2/screens/familyhome.dart';
import 'package:dav2/screens/faqhome.dart';
import 'package:dav2/screens/form16.dart';
import 'package:dav2/screens/por.dart';
import 'package:dav2/screens/resettlementhome.dart';
import 'package:flutter/material.dart';
import 'Contacts.dart';
import 'Coursemateshome.dart';
import 'Ig1.dart';
import 'Ig2.dart';
import 'Ig3.dart';
import 'Ig4.dart';
import 'Ig5.dart';
import 'Ig6.dart';
import 'Ig7.dart';
import 'Ig8.dart';
import 'Ig9.dart';
import 'informationvideo.dart';
import 'maindrawer.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late stt.SpeechToText _speech;
  bool _isListening = false;
  String _text = "Press the button and start speaking";
  // double confidence = 1.0;
// String text = 'Press the button and start speaking';
  @override
  void initState() {
    super.initState();
    _speech = stt.SpeechToText();
  }

  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    final maxLines;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF394361),
        title: Text(
          "VAYU-SAMPARC",
          style: TextStyle(fontSize: 20),
        ),
        actions: [
          IconButton(
              onPressed: _listen,
              // toggleRecording,
              icon: Icon(_isListening ? Icons.mic : Icons.mic_none)),
          Image(image: AssetImage("assets/images/newlogo.png"))
        ],
      ),
      drawer: Maindrawer(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 0.5, sigmaY: 0.5),
                child: Container(
                  color: Colors.grey.withOpacity(0.1),
                ),
              ),
              // width: MediaQuery.of(context).size.width*1.5,
              // height: MediaQuery.of(context).size.height*0.43,
              // height: 350,
              // width: 400,
              height: size.height * 0.26,
              width: size.width * 1.5,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(
                    "assets/images/B2.jpg",
                  ),
                  fit: BoxFit.fill,
                ),
              ),
            ),
            SizedBox(
              height: size.height * 0.02,
            ),
            Container(
              height: size.height * 0.19,
              width: size.width * 0.89,
              child: Card(
                color: Color(0xFFf2fcff),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                              left: MediaQuery.of(context).size.width / 30),
                          child: Text(
                            "Services",
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF474b50)),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          height: size.height * 0.06,
                          width: size.width * 0.15,
                          padding: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          margin: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 40),
                          decoration: BoxDecoration(
                            color: Color(0xFFd3eaf2),
                            border: Border.all(width: 0.3, color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),

                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Service1()),
                              );
                            },
                            child: Column(
                              children: [
                                Container(
                                    height: size.height * 0.02,
                                    width: size.width * 0.15,
                                    child: Image(
                                        image: AssetImage(
                                            "assets/images/servicep.png"))),
                                Padding(
                                  padding: EdgeInsets.only(
                                      left: MediaQuery.of(context).size.width /
                                          30),

                                  child: AutoSizeText(
                                    "SERVICE PENSION",
                                    style: TextStyle(

                                        color: Color(0xFF2c444d),
                                        fontSize: 7,
                                        fontWeight: FontWeight.bold),
                                    minFontSize: 3,
                                    maxFontSize: 9,
                                    maxLines: 2,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          height: size.height * 0.06,
                          width: size.width * 0.15,
                          padding: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          margin: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 40),
                          decoration: BoxDecoration(
                            color: Color(0xFFd3eaf2),
                            // color: Color(0xFFfec579),
                            // color: Colors.white,
                            border: Border.all(width: 0.3, color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Disability1()),
                              );
                            },
                            child: Column(
                              children: [
                                Container(
                                    height: size.height * 0.02,
                                    width: size.width * 0.15,
                                    child: Image(
                                        image: AssetImage(
                                            "assets/images/disabilityp.png"))),
                                Padding(
                                  padding: EdgeInsets.only(
                                      left: MediaQuery.of(context).size.width /
                                          30),
                                  child: AutoSizeText(
                                    "DISABILITY PENSION",
                                    style: TextStyle(
                                        color: Color(0xFF2c444d),
                                        fontSize: 7,
                                        fontWeight: FontWeight.bold),
                                    minFontSize: 3,
                                    maxFontSize: 9,
                                    maxLines: 2,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          height: size.height * 0.06,
                          width: size.width * 0.15,
                          padding: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          margin: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 40),
                          decoration: BoxDecoration(
                            color: Color(0xFFd3eaf2),
                            border: Border.all(width: 0.3, color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),

                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Family1()),
                              );
                            },
                            child: Column(
                              children: [
                                Container(
                                    height: size.height * 0.02,
                                    width: size.width * 0.15,
                                    child: Image(
                                        image: AssetImage(
                                            "assets/images/familyp.png"))),
                                Padding(
                                  padding: EdgeInsets.only(
                                      left: MediaQuery.of(context).size.width /
                                          30),
                                  child: AutoSizeText(
                                    "FAMILY PENSION",
                                    style: TextStyle(
                                        color: Color(0xFF2c444d),
                                        fontSize: 7,
                                        fontWeight: FontWeight.bold),
                                    minFontSize: 3,
                                    maxFontSize: 9,
                                    maxLines: 2,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          height: size.height * 0.06,
                          width: size.width * 0.15,
                          padding: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          margin: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          decoration: BoxDecoration(
                            color: Color(0xFFd3eaf2),
                            border: Border.all(width: 0.3, color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),

                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => Eppo()),
                              );
                            },
                            child: Column(
                              children: [
                                Container(
                                    height: size.height * 0.02,
                                    width: size.width * 0.15,
                                    child: Image(
                                        image: AssetImage(
                                            "assets/images/eppo.png"))),
                                Padding(
                                  padding: EdgeInsets.only(
                                      left: MediaQuery.of(context).size.width /
                                          180),
                                  child: AutoSizeText(
                                    "EPPO",
                                    style: TextStyle(
                                        color: Color(0xFF2c444d),
                                        fontSize: 8,
                                        fontWeight: FontWeight.bold),
                                    minFontSize: 3,
                                    maxFontSize: 9,
                                    maxLines: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          height: size.height * 0.06,
                          width: size.width * 0.15,
                          padding: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          margin: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          decoration: BoxDecoration(
                            color: Color(0xFFd3eaf2),
                            border: Border.all(width: 0.3, color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),

                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Form16()),
                              );
                            },
                            child: Column(
                              children: [
                                Container(
                                    height: size.height * 0.02,
                                    width: size.width * 0.15,
                                    child: Image(
                                        image: AssetImage(
                                            "assets/images/form16.png"))),
                                Padding(
                                  padding: EdgeInsets.only(
                                      left: MediaQuery.of(context).size.width /
                                          180),
                                  child: AutoSizeText(
                                    "FORM 16",
                                    style: TextStyle(
                                        color: Color(0xFF2c444d),
                                        fontSize: 8,
                                        fontWeight: FontWeight.bold),
                                    minFontSize: 3,
                                    maxFontSize: 9,
                                    maxLines: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          height: size.height * 0.06,
                          width: size.width * 0.15,
                          padding: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          margin: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          decoration: BoxDecoration(
                            color: Color(0xFFd3eaf2),
                            border: Border.all(width: 0.3, color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),

                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => Por()),
                              );
                            },
                            child: Column(
                              children: [
                                Container(
                                    height: size.height * 0.02,
                                    width: size.width * 0.15,
                                    child: Image(
                                        image: AssetImage(
                                            "assets/images/por.png"))),
                                Padding(
                                  padding: EdgeInsets.only(
                                      left: MediaQuery.of(context).size.width /
                                          180),
                                  child: AutoSizeText(
                                    "POR",
                                    style: TextStyle(
                                        color: Color(0xFF2c444d),
                                        fontSize: 8,
                                        fontWeight: FontWeight.bold),
                                    minFontSize: 3,
                                    maxFontSize: 9,
                                    maxLines: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              height: size.height * 0.19,
              width: size.width * 0.89,
              child: Card(
                color: Color(0xFFf2fcff),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                              left: MediaQuery.of(context).size.width / 30),
                          child: Text(
                            "Informations",
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF474b50)),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          height: size.height * 0.06,
                          width: size.width * 0.15,
                          padding: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          margin: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 40),
                          decoration: BoxDecoration(
                            color: Color(0xFFd3eaf2),
                            border: Border.all(width: 0.3, color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),

                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Update1()),
                              );
                            },
                            child: Column(
                              children: [
                                Container(
                                    height: size.height * 0.02,
                                    width: size.width * 0.15,
                                    child: Image(
                                        image: AssetImage(
                                            "assets/images/update.png"))),
                                Padding(
                                  padding: EdgeInsets.symmetric(
                                    horizontal:
                                        MediaQuery.of(context).size.width / 30,
                                    vertical:
                                        MediaQuery.of(context).size.width / 80,
                                  ),
                                  child: AutoSizeText(
                                    "UPDATES",
                                    style: TextStyle(
                                        color: Color(0xFF2c444d),
                                        fontSize: 6,
                                        fontWeight: FontWeight.bold),
                                    minFontSize: 3,
                                    maxFontSize: 9,
                                    maxLines: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          height: size.height * 0.06,
                          width: size.width * 0.15,
                          padding: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          margin: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 40),
                          decoration: BoxDecoration(
                            color: Color(0xFFd3eaf2),
                            border: Border.all(width: 0.3, color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),

                          child: GestureDetector(
                            onTap: () {
                              // Navigator.push(
                              //   context,
                              //   MaterialPageRoute(
                              //       builder: (context) =>
                              //       notification()),
                              // );
                            },
                            child: Column(
                              children: [
                                Container(
                                    //
                                    // height: 30
                                    // ,width: 50,
                                    height: size.height * 0.02,
                                    width: size.width * 0.2,
                                    child: Image(
                                        image: AssetImage(
                                            "assets/images/noticeboard.png"))),
                                Padding(
                                  padding: EdgeInsets.symmetric(
                                    horizontal:
                                        MediaQuery.of(context).size.width / 100,
                                    vertical:
                                        MediaQuery.of(context).size.width / 80,
                                  ),
                                  child: AutoSizeText(
                                    "NOTICE BOARD",
                                    style: TextStyle(
                                        color: Color(0xFF2c444d),
                                        fontSize: 6,
                                        fontWeight: FontWeight.bold),
                                    minFontSize: 3,
                                    maxFontSize: 9,
                                    maxLines: 2,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          height: size.height * 0.06,
                          width: size.width * 0.15,
                          // height: 70,
                          // width:90,
                          // margin: EdgeInsets.only(top:15),
                          // padding: EdgeInsets.only(top: 10),
                          padding: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          margin: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 40),
                          decoration: BoxDecoration(
                            color: Color(0xFFd3eaf2),
                            // color: Colors.white,
                            // color: Color(0xFFfec579),
                            border: Border.all(width: 0.3, color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),

                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => InformationVideo()),
                              );
                            },
                            child: Column(
                              children: [
                                Container(

                                    // height: 30
                                    // ,width: 50,
                                    height: size.height * 0.02,
                                    width: size.width * 0.15,
                                    child: Image(
                                        image: AssetImage(
                                            "assets/images/video.png"))),
                                Padding(
                                  padding: EdgeInsets.symmetric(
                                    horizontal:
                                        MediaQuery.of(context).size.width / 90,
                                    vertical:
                                        MediaQuery.of(context).size.width / 300,
                                  ),
                                  child: AutoSizeText(
                                    "INFORMATION VIDEO",
                                    style: TextStyle(
                                        color: Color(0xFF2c444d),
                                        fontSize: 6,
                                        fontWeight: FontWeight.bold),
                                    minFontSize: 3,
                                    maxFontSize: 8,
                                    maxLines: 2,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                              left: MediaQuery.of(context).size.width / 10),
                          child: Container(
                            height: size.height * 0.06,
                            width: size.width * 0.15,
                            // height: 70,
                            // width:90,
                            // margin: EdgeInsets.only(top:15),
                            // padding: EdgeInsets.only(top: 10),
                            padding: EdgeInsets.only(
                                top: MediaQuery.of(context).size.width / 30),
                            margin: EdgeInsets.only(
                                top: MediaQuery.of(context).size.width / 30),
                            decoration: BoxDecoration(
                              color: Color(0xFFd3eaf2),
                              // color: Colors.white,
                              // color: Color(0xFFfec579),
                              border:
                                  Border.all(width: 0.3, color: Colors.grey),
                              borderRadius: BorderRadius.circular(8),
                            ),

                            child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => Resettlement1()),
                                );
                              },
                              child: Column(
                                children: [
                                  Container(

                                      // height: 30
                                      // ,width: 50,
                                      height: size.height * 0.02,
                                      width: size.width * 0.15,
                                      child: Image(
                                          image: AssetImage(
                                              "assets/images/resettlement.png"))),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left:
                                            MediaQuery.of(context).size.width /
                                                80),
                                    child: AutoSizeText(
                                      "RESETTLEMENT",
                                      style: TextStyle(
                                          color: Color(0xFF2c444d),
                                          fontSize: 6,
                                          fontWeight: FontWeight.bold),
                                      minFontSize: 3,
                                      maxFontSize: 8,
                                      maxLines: 2,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: MediaQuery.of(context).size.width / 9),
                          child: Container(
                            height: size.height * 0.06,
                            width: size.width * 0.15,
                            // height: 70,
                            // width:90,
                            // margin: EdgeInsets.only(top:15),
                            // padding: EdgeInsets.only(top: 10),
                            padding: EdgeInsets.only(
                                top: MediaQuery.of(context).size.width / 30),
                            margin: EdgeInsets.only(
                                top: MediaQuery.of(context).size.width / 30),
                            decoration: BoxDecoration(
                              color: Color(0xFFd3eaf2),
                              // color: Colors.white,
                              // color: Color(0xFFfec579),
                              border:
                                  Border.all(width: 0.3, color: Colors.grey),
                              borderRadius: BorderRadius.circular(8),
                            ),

                            child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => Faqofficer1()),
                                );
                              },
                              child: Column(
                                children: [
                                  Container(
                                      //
                                      // height: 30
                                      // ,width: 50,
                                      height: size.height * 0.02,
                                      width: size.width * 0.15,
                                      child: Image(
                                          image: AssetImage(
                                              "assets/images/faq.png"))),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                      horizontal:
                                          MediaQuery.of(context).size.width /
                                              30,
                                      vertical:
                                          MediaQuery.of(context).size.width /
                                              110,
                                    ),
                                    child: AutoSizeText(
                                      "FAQs",
                                      style: TextStyle(
                                          color: Color(0xFF2c444d),
                                          fontSize: 6,
                                          fontWeight: FontWeight.bold),
                                      minFontSize: 3,
                                      maxFontSize: 9,
                                      maxLines: 1,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: MediaQuery.of(context).size.width / 9),
                          child: Container(
                            height: size.height * 0.06,
                            width: size.width * 0.15,
                            padding: EdgeInsets.only(
                                top: MediaQuery.of(context).size.width / 30),
                            margin: EdgeInsets.only(
                                top: MediaQuery.of(context).size.width / 30),
                            decoration: BoxDecoration(
                              color: Color(0xFFd3eaf2),
                              // color: Colors.white,
                              // color: Color(0xFFfec579),
                              border:
                                  Border.all(width: 0.3, color: Colors.grey),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => Echs1()),
                                );
                              },
                              child: Column(
                                children: [
                                  Container(
                                      height: size.height * 0.02,
                                      width: size.width * 0.15,
                                      child: Image(
                                          image: AssetImage(
                                              "assets/images/welfare.png"))),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left:
                                            MediaQuery.of(context).size.width /
                                                40),
                                    child: AutoSizeText(
                                      "ECHS & WELFARE ",
                                      style: TextStyle(
                                          color: Color(0xFF2c444d),
                                          fontSize: 7,
                                          fontWeight: FontWeight.bold),
                                      minFontSize: 3,
                                      maxFontSize: 9,
                                      maxLines: 2,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              // height: 130,
              // width: 320,
              height: size.height * 0.12,
              width: size.width * 0.89,
              child: Card(
                color: Color(0xFFf2fcff),
                margin: EdgeInsets.fromLTRB(
                    MediaQuery.of(context).size.width / 60, 0.08, 3, 8),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                              left: MediaQuery.of(context).size.width / 30),
                          child: Text(
                            "Search",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF474b50),
                              fontSize: 15,
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          height: size.height * 0.06,
                          width: size.width * 0.15,
                          padding: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          margin: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          decoration: BoxDecoration(
                            color: Color(0xFFd3eaf2),
                            border: Border.all(width: 0.3, color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),

                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Coursemates()),
                              );
                            },
                            child: Column(
                              children: [
                                Container(
                                    height: size.height * 0.02,
                                    width: size.width * 0.15,
                                    child: Image(
                                        image: AssetImage(
                                            "assets/images/coursemates.png"))),
                                Padding(
                                  padding: EdgeInsets.symmetric(
                                    horizontal:
                                        MediaQuery.of(context).size.width / 50,
                                    vertical:
                                        MediaQuery.of(context).size.width / 200,
                                  ),
                                  child: AutoSizeText(
                                    "Course Mates",
                                    style: TextStyle(
                                        color: Color(0xFF2c444d),
                                        fontSize: 7,
                                        fontWeight: FontWeight.bold),
                                    minFontSize: 3,
                                    maxFontSize: 9,
                                    maxLines: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          // ),
                        ),
                        Container(
                          height: size.height * 0.06,
                          width: size.width * 0.15,
                          padding: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          margin: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          decoration: BoxDecoration(
                            color: Color(0xFFd3eaf2),
                            border: Border.all(width: 0.3, color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => EchsMap()),
                              );
                            },
                            child: Column(
                              children: [
                                Container(
                                    height: size.height * 0.02,
                                    width: size.width * 0.15,
                                    child: Image(
                                        image: AssetImage(
                                            "assets/images/echs.png"))),
                                Padding(
                                  padding: EdgeInsets.symmetric(
                                    horizontal:
                                        MediaQuery.of(context).size.width / 40,
                                    vertical:
                                        MediaQuery.of(context).size.width / 200,
                                  ),
                                  // padding: EdgeInsets.only(left: MediaQuery.of(context).size.width/30),
                                  child: AutoSizeText(
                                    "ECHS/URC",
                                    style: TextStyle(
                                        color: Color(0xFF2c444d),
                                        fontSize: 9,
                                        fontWeight: FontWeight.bold),
                                    minFontSize: 3,
                                    maxFontSize: 9,
                                    maxLines: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          height: size.height * 0.06,
                          width: size.width * 0.15,
                          padding: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          margin: EdgeInsets.only(
                              top: MediaQuery.of(context).size.width / 30),
                          decoration: BoxDecoration(
                            color: Color(0xFFd3eaf2),
                            border: Border.all(width: 0.3, color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Contacts()),
                              );
                            },
                            child: Column(
                              children: [
                                Container(
                                    height: size.height * 0.023,
                                    width: size.width * 0.15,
                                    child: Image(
                                        image: AssetImage(
                                            "assets/images/contacts.png"))),
                                Padding(
                                  padding: EdgeInsets.symmetric(
                                    horizontal:
                                        MediaQuery.of(context).size.width / 40,
                                    vertical:
                                        MediaQuery.of(context).size.width / 200,
                                  ),
                                  // padding:  EdgeInsets.only(left: MediaQuery.of(context).size.width/30),
                                  child: AutoSizeText(
                                    "Contacts ",
                                    style: TextStyle(
                                        color: Color(0xFF2c444d),
                                        fontSize: 8,
                                        fontWeight: FontWeight.bold),
                                    minFontSize: 3,
                                    maxFontSize: 9,
                                    maxLines: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Container(
              margin:
                  EdgeInsets.only(top: MediaQuery.of(context).size.width / 60),
              height: size.height * 0.07,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      stops: [0.3, 1],
                      colors: [Color(0xFF394361), Color(0xFFa8d5e5)])),
              child: CarouselSlider(
                items: [
                  Padding(
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.width / 400),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Ig1()),
                        );
                      },
                      // onTap: () =>
                      //     launchUrl(Uri.parse('  http://www.ksb.gov.in/')),
                      child: Container(
                        // height: 30,
                        // width: 150,
                        height: size.height * 0.09,
                        width: size.width * 0.25,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage("assets/images/Img1.1.png"),
                            // fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.width / 300),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Ig2()),
                        );
                      },
                      // onTap: () =>
                      //     launchUrl(Uri.parse('https://www.india.gov.in/')),
                      child: Container(
                        // height: 30,
                        // width: 150,
                        height: size.height * 0.09,
                        width: size.width * 0.25,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage("assets/images/Img2.png"),
                            // fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Ig3()),
                        );
                      },
                      // onTap: () => launchUrl(
                      //     Uri.parse('https://indianairforce.nic.in/')),
                      child: Container(
                        // height:30,
                        // width: 150,
                        height: size.height * 0.09,
                        width: size.width * 0.25,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage("assets/images/Img3.png"),
                            // fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.width / 300),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Ig4()),
                        );
                      },
                      // onTap: () => launchUrl(Uri.parse(
                      //     'https://joinindianarmy.nic.in/default.aspx')),
                      child: Container(
                        // height: 30,
                        // width: 150,
                        height: size.height * 0.09,
                        width: size.width * 0.25,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage("assets/images/Img4.jpg"),
                            // fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.width / 300),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Ig5()),
                        );
                      },

                      // onTap: () => launchUrl(
                      //     Uri.parse('https://www.joinindiannavy.gov.in/')),
                      child: Container(
                        // height: 30,
                        // width: 150,
                        height: size.height * 0.09,
                        width: size.width * 0.25,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage("assets/images/Img5.png"),
                            // fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.width / 300),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Ig6()),
                        );
                      },
                      // onTap: () => launchUrl(Uri.parse(
                      //     'https://iafpensioners.gov.in/ords/dav_portal/r/afgis/home')),
                      child: Container(
                        // height: 30,
                        // width: 150,
                        height: size.height * 0.09,
                        width: size.width * 0.25,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage("assets/images/Img6.png"),
                            // fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.width / 300),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Ig7()),
                        );
                      },
                      // onTap: () => launchUrl(Uri.parse(
                      //     'https://iafpensioners.gov.in/ords/dav_portal/r/dte_av/useful-links?p0_title=OTHER%20LINKS')),
                      child: Container(
                        // height: 30,
                        // width: 150,
                        height: size.height * 0.09,
                        width: size.width * 0.25,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage("assets/images/Img7.png"),
                            // fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.width / 300),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Ig8()),
                        );
                      },
                      // onTap: () =>
                      //     launchUrl(Uri.parse('https://www.mygov.in/')),
                      child: Container(
                        // height: 30,
                        // width: 150,
                        height: size.height * 0.09,
                        width: size.width * 0.25,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage("assets/images/Img8.jpg"),
                            // fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.width / 300),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Ig9()),
                        );
                      },
                      // onTap: () =>
                      //     launchUrl(Uri.parse('https://www.desw.gov.in/')),
                      child: Container(
                        // height: 30,
                        // width: 150,
                        height: size.height * 0.09,
                        width: size.width * 0.25,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage("assets/images/Img9.png"),
                            // fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
                options: CarouselOptions(
                  height: size.height * 0.05,
                  enlargeCenterPage: false,
                  autoPlay: true,
                  aspectRatio: 16 / 9,
                  autoPlayCurve: Curves.fastOutSlowIn,
                  enableInfiniteScroll: true,
                  autoPlayAnimationDuration: Duration(milliseconds: 5),
                  viewportFraction: 0.3,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _listen() async {
    if (!_isListening) {
      bool available = await _speech.initialize(
        onStatus: (val) => print('onStatus: $val'),
        onError: (val) => print('onError: $val'),
      );
      if (available) {
        setState(() => _isListening = true);
        _speech.listen(
          onResult: (val) => setState(() {
            _text = val.recognizedWords;
          }),
        );
      } else {
        setState(() => _isListening = false);
        _speech.stop();
      }
    }
  }
  // void toggleRecording() {
  //
  //   SpeechApi.toggleRecording(
  //     onResult: (String text) => setState(() => this.text=text),
  //
  //   );
  // }
}
