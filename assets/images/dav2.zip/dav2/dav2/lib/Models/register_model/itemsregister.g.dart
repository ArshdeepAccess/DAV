// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'itemsregister.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Items _$ItemsFromJson(Map<String, dynamic> json) => Items(
      result: json['result'] as int?,

    );

Map<String, dynamic> _$ItemsToJson(Items instance) => <String, dynamic>{
      'result': instance.result,

    };
