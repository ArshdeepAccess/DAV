// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'itemsfaqofficer.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Items _$ItemsFromJson(Map<String, dynamic> json) => Items(
      hsd_sr_no: json['hsd_sr_no'] as int?,
      hsd_detail: json['hsd_detail'] as String?,
      hsd_pdf_link: json['hsd_pdf_link'] as String?,
    );

Map<String, dynamic> _$ItemsToJson(Items instance) => <String, dynamic>{
      'hsd_sr_no': instance.hsd_sr_no,
      'hsd_detail': instance.hsd_detail,
      'hsd_pdf_link': instance.hsd_pdf_link,
    };
