// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'itemsechsmain.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Items _$ItemsFromJson(Map<String, dynamic> json) => Items(
      d: json['d'] as String?,
      r: json['r'] as String?,
    );

Map<String, dynamic> _$ItemsToJson(Items instance) => <String, dynamic>{
      'd': instance.d,
      'r': instance.r,
    };
