// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'linksservice.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Links _$LinksFromJson(Map<String, dynamic> json) => Links(
      rel: json['rel'] as String?,
      href: json['href'] as String?,
    );

Map<String, dynamic> _$LinksToJson(Links instance) => <String, dynamic>{
      'rel': instance.rel,
      'href': instance.href,
    };
